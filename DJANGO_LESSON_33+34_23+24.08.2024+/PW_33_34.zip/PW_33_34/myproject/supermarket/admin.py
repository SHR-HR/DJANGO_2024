from django.contrib import admin
from .models import SupermarketItem


@admin.register(SupermarketItem)
class SupermarketItemAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'stock')
    search_fields = ('name', 'details')
    list_filter = ('price', 'stock')
