from django.contrib import admin
from .models import Amenity


@admin.register(Amenity)
class AmenityAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'available_times')
    search_fields = ('name', 'description', 'tags')
    list_filter = ('price', 'tags')
