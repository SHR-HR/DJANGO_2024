from django.contrib import admin
from .models import Room


@admin.register(Room)
class RoomAdmin(admin.ModelAdmin):
    list_display = ('name', 'beds', 'available_dates')
    search_fields = ('name',)
    list_filter = ('beds',)
