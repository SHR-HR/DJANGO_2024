from django.db import models
from django.contrib.postgres.fields import DateRangeField
from django.contrib.postgres.indexes import GistIndex
from django.contrib.postgres.constraints import ExclusionConstraint
from django.contrib.postgres.validators import RangeMinValueValidator, RangeMaxValueValidator
from datetime import date


class Room(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название комнаты")
    beds = models.IntegerField(verbose_name="Количество кроватей", default=1)
    available_dates = DateRangeField(
        verbose_name="Доступные даты",
        validators=[
            RangeMinValueValidator(date(2022, 1, 1)),
            RangeMaxValueValidator(date(2030, 12, 31))
        ],
        default=(date(2022, 1, 1), date(2022, 1, 1))
    )

    class Meta:
        verbose_name = "Комната"
        verbose_name_plural = "Комнаты"
        indexes = [
            GistIndex(fields=['available_dates']),
        ]
        constraints = [
            ExclusionConstraint(
                name='exclude_overlapping_dates',
                expressions=[
                    ('available_dates', '&&'),
                ],
            ),
        ]

    def __str__(self):
        return self.name


