document.addEventListener('DOMContentLoaded', function () {
    const createdAtInput = document.querySelector('#id_created_at');
    const updatedAtInput = document.querySelector('#id_updated_at');
    if (createdAtInput && updatedAtInput) {
        const nowButton = document.createElement('button');
        nowButton.type = 'button';
        nowButton.innerText = 'Set to Now';
        nowButton.onclick = function () {
            const now = new Date().toISOString().slice(0, 16);
            createdAtInput.value = now;
            updatedAtInput.value = now;
        };
        createdAtInput.parentNode.appendChild(nowButton);
    }
});
