from django.contrib import admin
from .models import Task
from .forms import TaskAdminForm

class TaskAdmin(admin.ModelAdmin):
    form = TaskAdminForm

admin.site.register(Task, TaskAdmin)
