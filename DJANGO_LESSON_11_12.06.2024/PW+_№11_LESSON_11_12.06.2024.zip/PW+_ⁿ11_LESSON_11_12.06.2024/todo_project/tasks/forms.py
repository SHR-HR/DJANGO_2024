from django import forms
from .models import Task

class TaskAdminForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = '__all__'
        widgets = {
            'created_at': forms.DateTimeInput(attrs={'type': 'datetime-local'}, format='%Y-%m-%dT%H:%M'),
            'updated_at': forms.DateTimeInput(attrs={'type': 'datetime-local'}, format='%Y-%m-%dT%H:%M')
        }

    class Media:
        js = ('js/admin_custom.js',)

    def __init__(self, *args, **kwargs):
        super(TaskAdminForm, self).__init__(*args, **kwargs)

        if 'created_at' in self.fields:
            self.fields['created_at'].input_formats = ('%Y-%m-%dT%H:%M',)
        if 'updated_at' in self.fields:
            self.fields['updated_at'].input_formats = ('%Y-%m-%dT%H:%M',)
