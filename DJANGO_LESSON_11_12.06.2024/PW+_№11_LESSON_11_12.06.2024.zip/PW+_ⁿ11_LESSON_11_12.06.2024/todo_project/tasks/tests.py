from django.test import TestCase
from .models import Task
from django.core.exceptions import ValidationError

class TaskModelTests(TestCase):

    def test_task_creation(self):
        task = Task.objects.create(title="Test Task", description="Test description")
        self.assertEqual(task.title, "Test Task")
        self.assertIn("Test", task.title)

    def test_task_validation_error(self):
        with self.assertRaises(ValidationError):
            task = Task.objects.create(title="Short", description="Too short description")
            task.full_clean()
