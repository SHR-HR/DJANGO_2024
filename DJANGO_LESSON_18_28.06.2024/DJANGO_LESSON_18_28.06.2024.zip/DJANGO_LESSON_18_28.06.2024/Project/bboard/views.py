from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.models import User
from django.views.generic import ListView, DetailView, View
from django.http import JsonResponse
from .models import Bb, Rubric, Comment
from .forms import BbForm
from django.urls import reverse_lazy

class BbListView(ListView):
    model = Bb
    template_name = 'bboard/index.html'
    context_object_name = 'bbs'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['rubrics'] = Rubric.objects.all()
        return context

class BbDetailView(DetailView):
    model = Bb
    template_name = 'bboard/detail.html'
    context_object_name = 'bb'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['rubrics'] = Rubric.objects.all()
        return context

class BbCreateView(View):
    form_class = BbForm
    template_name = 'bboard/create.html'
    success_url = reverse_lazy('bboard:index')

    def get_context_data(self, **kwargs):
        context = {
            'rubrics': Rubric.objects.all(),
        }
        return context

    def get(self, request, *args, **kwargs):
        form = self.form_class()
        return render(request, self.template_name, {'form': form, **self.get_context_data()})

    def post(self, request, *args, **kwargs):
        form = self.form_class(request.POST)
        if form.is_valid():
            form.save()
            return redirect(self.success_url)
        return render(request, self.template_name, {'form': form, **self.get_context_data()})

class FirstUserView(View):
    template_name = 'bboard/first_user.html'

    def get_context_data(self, **kwargs):
        context = {
            'rubrics': Rubric.objects.all(),
        }
        return context

    def get(self, request, *args, **kwargs):
        first_user = User.objects.first()
        context = {
            'user': first_user,
            **self.get_context_data(),
        }
        return render(request, self.template_name, context)

class BbByRubricView(ListView):
    template_name = 'bboard/by_rubric.html'
    context_object_name = 'bbs'

    def get_queryset(self):
        return Bb.objects.filter(rubric=self.kwargs['rubric_id'])

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['rubrics'] = Rubric.objects.all()
        context['current_rubric'] = get_object_or_404(Rubric, pk=self.kwargs['rubric_id'])
        return context

def get_comments(request):
    comments = Comment.objects.all().values('id', 'text', 'created_at')
    return JsonResponse(list(comments), safe=False)

def get_comment_by_id(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    return JsonResponse({'id': comment.id, 'text': comment.text, 'created_at': comment.created_at})

def delete_comment(request, comment_id):
    try:
        comment = Comment.objects.get(id=comment_id)
        comment.delete()
        return JsonResponse({'status': 'success'})
    except Comment.DoesNotExist:
        return JsonResponse({'status': 'comment not found'}, status=404)

def redirect_to_index(request):
    return redirect('bboard:index')

def add_and_save(request):
    if request.method == 'POST':
        form = BbForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('bboard:by_rubric', rubric_id=form.cleaned_data['rubric'].pk)
        return render(request, 'bboard/create.html', {'form': form, 'rubrics': Rubric.objects.all()})
    else:
        form = BbForm()
        return render(request, 'bboard/create.html', {'form': form, 'rubrics': Rubric.objects.all()})

def redirect_to_rubric(request, rubric_id):
    return redirect('bboard:by_rubric', rubric_id=rubric_id)

# Класс для вывода данных всех пользователей
class UserListView(ListView):
    model = User
    template_name = 'bboard/user_list.html'
    context_object_name = 'users'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['rubrics'] = Rubric.objects.all()
        return context

# Класс для вывода данных конкретного пользователя
class UserDetailView(DetailView):
    model = User
    template_name = 'bboard/user_detail.html'
    context_object_name = 'user'
    pk_url_kwarg = 'user_id'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['rubrics'] = Rubric.objects.all()
        return context

# Класс для поиска пользователя
class UserSearchView(View):
    template_name = 'bboard/user_search.html'

    def get_context_data(self, **kwargs):
        context = {
            'rubrics': Rubric.objects.all(),
        }
        return context

    def get(self, request):
        return render(request, self.template_name, self.get_context_data())

    def post(self, request):
        username = request.POST.get('username')
        user = get_object_or_404(User, username=username)
        context = {
            'user': user,
            **self.get_context_data(),
        }
        return render(request, 'bboard/user_detail.html', context)


