from django.urls import path
from .views import BbListView, BbCreateView, get_comments, get_comment_by_id, delete_comment, add_and_save, redirect_to_index, BbByRubricView, BbDetailView, FirstUserView, UserListView, UserDetailView, redirect_to_rubric, UserSearchView

app_name = 'bboard'

urlpatterns = [
    path('comments/', get_comments, name='get_comments'),
    path('comments/<int:comment_id>/', get_comment_by_id, name='get_comment_by_id'),
    path('comments/delete/<int:comment_id>/', delete_comment, name='delete_comment'),
    path('add-and-save/', add_and_save, name='add_and_save'),
    path('add/', BbCreateView.as_view(), name='add'),
    path('<int:rubric_id>/', BbByRubricView.as_view(), name='by_rubric'),
    path('', BbListView.as_view(), name='index'),  # Обновленный маршрут для главной страницы
    path('redirect/', redirect_to_index, name='redirect_to_index'),
    path('detail/<int:pk>/', BbDetailView.as_view(), name='detail'),
    path('redirect/<int:rubric_id>/', redirect_to_rubric, name='redirect_to_rubric'),
    path('first-user/', FirstUserView.as_view(), name='first_user'),  # Маршрут для вывода данных первого пользователя
    path('users/', UserListView.as_view(), name='user_list'),  # Маршрут для вывода данных всех пользователей
    path('users/<int:user_id>/', UserDetailView.as_view(), name='user_detail'),  # Маршрут для вывода данных конкретного пользователя
    path('user_search/', UserSearchView.as_view(), name='user_search'),  # Маршрут для поиска пользователя
]



