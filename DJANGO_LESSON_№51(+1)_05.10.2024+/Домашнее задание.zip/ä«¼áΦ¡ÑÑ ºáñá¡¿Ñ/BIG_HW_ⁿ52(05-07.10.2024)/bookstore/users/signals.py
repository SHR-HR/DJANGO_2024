from django.db.models.signals import post_save, pre_delete
from django.contrib.auth.models import User
from django.dispatch import receiver
from notification.models import Notification, Subscription, NotificationType
from django.core.exceptions import ObjectDoesNotExist
from django.db.utils import IntegrityError

def get_admin_user():
    try:
        return User.objects.get(username='IAMSUPERUZZZER')
    except ObjectDoesNotExist:
        print("Ошибка: Администратор с username 'IAMSUPERUZZZER' не найден.")
        return None

def get_or_create_admin_subscription(admin_user):
    try:
        return Subscription.objects.get_or_create(user=admin_user)
    except IntegrityError:
        print(f"Ошибка создания или получения подписки для пользователя {admin_user}.")
        return None, False

@receiver(post_save, sender=User)
def notify_admin_on_new_user(sender, instance, created, **kwargs):
    admin_user = get_admin_user()
    if not admin_user:
        return

    admin_subscription, _ = get_or_create_admin_subscription(admin_user)
    if not admin_subscription:
        return

    if created:
        notification_type, _ = NotificationType.objects.get_or_create(
            type_code='user_signup',
            defaults={'description': 'Регистрация пользователя'}
        )
        Notification.objects.create(
            user=admin_user,
            message=f'Новый пользователь зарегистрирован: {instance.username}',
            notification_type=notification_type
        )
        if not admin_subscription.subscribed_types.filter(pk=notification_type.pk).exists():
            admin_subscription.subscribed_types.add(notification_type)
    else:
        notification_type, _ = NotificationType.objects.get_or_create(
            type_code='profile_update',
            defaults={'description': 'Изменение профиля'}
        )
        Notification.objects.create(
            user=admin_user,
            message=f'Профиль пользователя {instance.username} был обновлен.',
            notification_type=notification_type
        )
        if not admin_subscription.subscribed_types.filter(pk=notification_type.pk).exists():
            admin_subscription.subscribed_types.add(notification_type)

@receiver(pre_delete, sender=User)
def notify_admin_on_user_delete(sender, instance, **kwargs):
    admin_user = get_admin_user()
    if not admin_user:
        return

    admin_subscription, _ = get_or_create_admin_subscription(admin_user)
    if not admin_subscription:
        return

    notification_type, _ = NotificationType.objects.get_or_create(
        type_code='profile_delete',
        defaults={'description': 'Удаление профиля'}
    )
    Notification.objects.create(
        user=admin_user,
        message=f'Пользователь {instance.username} был удален.',
        notification_type=notification_type
    )

    if not admin_subscription.subscribed_types.filter(pk=notification_type.pk).exists():
        admin_subscription.subscribed_types.add(notification_type)






