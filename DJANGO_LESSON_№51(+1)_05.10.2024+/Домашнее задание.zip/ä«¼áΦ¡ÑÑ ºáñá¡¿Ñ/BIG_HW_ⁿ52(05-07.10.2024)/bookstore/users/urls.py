from django.urls import path
from .views import UserListUpdateView, UserRegistrationView, UserDetailUpdateView

urlpatterns = [
    path('users/', UserListUpdateView.as_view(), name='user-list-update'),
    path('register/', UserRegistrationView.as_view(), name='user-register'),
    path('users/<int:pk>/', UserDetailUpdateView.as_view(), name='user-detail-update'),
]

