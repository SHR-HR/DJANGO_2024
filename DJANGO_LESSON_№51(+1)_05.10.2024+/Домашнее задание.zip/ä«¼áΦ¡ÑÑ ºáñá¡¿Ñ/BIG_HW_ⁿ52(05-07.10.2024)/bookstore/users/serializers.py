from rest_framework import serializers
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.contrib.auth.models import User
from django.dispatch import receiver
from notification.models import Notification, Subscription, NotificationType

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name']

@receiver(post_save, sender=User)
def notify_admin_on_new_user(sender, instance, created, **kwargs):
    if created:
        admin_user = User.objects.get(username='IAMSUPERUZZZER')
        notification_type, _ = NotificationType.objects.get_or_create(
            type_code='new_user_registration',
            defaults={'description': 'Регистрация нового пользователя'}
        )

        Notification.objects.create(
            user=admin_user,
            message=f'Новый пользователь зарегистрирован: {instance.username}',
            notification_type=notification_type.type_code
        )

        admin_subscription, _ = Subscription.objects.get_or_create(user=admin_user)
        if notification_type not in admin_subscription.subscribed_types.all():
            admin_subscription.subscribed_types.add(notification_type)




