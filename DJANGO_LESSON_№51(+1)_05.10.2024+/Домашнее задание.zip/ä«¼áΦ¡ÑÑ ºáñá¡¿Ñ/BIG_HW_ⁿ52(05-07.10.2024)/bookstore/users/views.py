from rest_framework.permissions import AllowAny
from rest_framework.generics import CreateAPIView
from rest_framework import generics, permissions
from django.contrib.auth.models import User
from .serializers import UserSerializer
from rest_framework import serializers


class IsAdminOrModerator(permissions.BasePermission):

    def has_permission(self, request, view):

        if request.user.is_staff or request.user.is_superuser:
            return True

        return request.user.groups.filter(name='Модераторы').exists()

class UserListUpdateView(generics.ListAPIView, generics.UpdateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer

    permission_classes = [IsAdminOrModerator]

class UserDetailUpdateView(generics.RetrieveUpdateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

class UserRegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'password', 'email']
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):

        user = User.objects.create_user(**validated_data)
        return user

class UserRegistrationView(CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserRegistrationSerializer
    permission_classes = [AllowAny]
    http_method_names = ['post', 'options']





