from rest_framework import generics, permissions
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.exceptions import PermissionDenied
from .models import Image
from rest_framework.response import Response
from .serializers import ImageSerializer, MultipleImageSerializer, MultiBookImageUploadSerializer

class ImageUploadView(generics.CreateAPIView):
    queryset = Image.objects.all()
    serializer_class = ImageSerializer
    parser_classes = [MultiPartParser, FormParser]
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(uploaded_by=self.request.user)

class MultipleImageUploadView(generics.CreateAPIView):
    queryset = Image.objects.all()
    serializer_class = MultipleImageSerializer
    parser_classes = [MultiPartParser, FormParser]
    permission_classes = [permissions.IsAuthenticated]

class MultiBookImageUploadView(generics.CreateAPIView):
    queryset = Image.objects.all()
    serializer_class = MultiBookImageUploadSerializer
    parser_classes = [MultiPartParser, FormParser]
    permission_classes = [permissions.IsAuthenticated]

    def create(self, request, *args, **kwargs):

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        images = serializer.save()
        return Response({
            "message": f"{len(images)} изображений успешно загружены.",
            "data": [
                {
                    "id": img.id,
                    "book": img.book_id,
                    "image": img.image.url,
                    "uploaded_by": img.uploaded_by_id,
                    "uploaded_at": img.uploaded_at,
                } for img in images
            ]
        })

class ImageDeleteView(generics.DestroyAPIView):
    queryset = Image.objects.all()
    permission_classes = [permissions.IsAdminUser]

    def delete(self, request, *args, **kwargs):
        if not request.user.is_staff:
            raise PermissionDenied("Только администраторы могут удалять изображения.")
        return super().delete(request, *args, **kwargs)





