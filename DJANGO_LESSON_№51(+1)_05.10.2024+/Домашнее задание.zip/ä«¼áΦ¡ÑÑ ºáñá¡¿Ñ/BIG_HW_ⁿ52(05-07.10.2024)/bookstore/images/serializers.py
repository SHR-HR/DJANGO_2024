from rest_framework import serializers
from .models import Image

class ImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Image
        fields = ['id', 'book', 'image', 'uploaded_by', 'uploaded_at']
        read_only_fields = ['uploaded_by', 'uploaded_at']

class MultipleImageSerializer(serializers.Serializer):
    images = serializers.ListField(
        child=serializers.ImageField(),
        allow_empty=False,
        write_only=True
    )
    book = serializers.IntegerField()

    def create(self, validated_data):
        book_id = validated_data['book']
        images = validated_data['images']
        uploaded_by = self.context['request'].user
        
        image_instances = [Image(book_id=book_id, image=image, uploaded_by=uploaded_by) for image in images]
        return Image.objects.bulk_create(image_instances)


class MultiBookImageUploadSerializer(serializers.Serializer):
    images = serializers.ListField(
        child=serializers.ImageField(),
        allow_empty=False,
        write_only=True
    )
    books = serializers.CharField()

    def validate_books(self, value):

        try:

            return [int(book_id) for book_id in value.split(',')]
        except ValueError:
            raise serializers.ValidationError("Введите правильный список чисел.")

    def create(self, validated_data):
        images = validated_data['images']
        books = validated_data['books']
        uploaded_by = self.context['request'].user

        image_instances = [
            Image(book_id=book_id, image=image, uploaded_by=uploaded_by) 
            for image, book_id in zip(images, books)
        ]
        return Image.objects.bulk_create(image_instances)


