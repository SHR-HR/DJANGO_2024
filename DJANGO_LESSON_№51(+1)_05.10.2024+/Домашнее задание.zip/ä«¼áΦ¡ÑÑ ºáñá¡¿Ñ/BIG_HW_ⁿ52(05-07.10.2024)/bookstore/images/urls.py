from django.urls import path
from .views import ImageUploadView, MultipleImageUploadView, MultiBookImageUploadView, ImageDeleteView

urlpatterns = [
    path('upload/', ImageUploadView.as_view(), name='image-upload'),
    path('upload/multiple/', MultipleImageUploadView.as_view(), name='multiple-image-upload'),
    path('upload/multi-book/', MultiBookImageUploadView.as_view(), name='multi-book-image-upload'),
    path('delete/<int:pk>/', ImageDeleteView.as_view(), name='image-delete'),
]





