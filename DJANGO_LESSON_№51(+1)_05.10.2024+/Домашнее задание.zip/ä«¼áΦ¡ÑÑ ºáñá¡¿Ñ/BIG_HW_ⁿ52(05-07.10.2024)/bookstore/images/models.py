from django.db import models
from django.contrib.auth.models import User
from books.models import Book
from PIL import Image as PilImage, ImageDraw, ImageFont
from io import BytesIO
from django.core.files import File
import os

class Image(models.Model):
    book = models.ForeignKey(Book, related_name='images', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='books/images/')
    uploaded_by = models.ForeignKey(User, on_delete=models.CASCADE)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Изображение'
        verbose_name_plural = 'Изображения'

    def save(self, *args, **kwargs):
        pil_image = PilImage.open(self.image)

        max_size = (800, 800)
        pil_image.thumbnail(max_size)

        watermark_text = "Book Store"
        draw = ImageDraw.Draw(pil_image)

        try:
            font_path = os.path.join(os.path.dirname(__file__), 'arial.ttf')
            font = ImageFont.truetype(font_path, 36)
        except IOError:
            font = ImageFont.load_default()

        width, height = pil_image.size
        textwidth, textheight = draw.textbbox((0, 0), watermark_text, font)[2:]
        x = width - textwidth - 10
        y = height - textheight - 10

        draw.text((x, y), watermark_text, font=font, fill=(255, 255, 255, 128))

        buffer = BytesIO()
        pil_image.save(buffer, format='JPEG')
        buffer.seek(0)

        self.image.save(self.image.name, File(buffer), save=False)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Изображение для книги {self.book.title}"





