from django.contrib import admin
from .models import Image

@admin.register(Image)
class ImageAdmin(admin.ModelAdmin):
    list_display = ('id', 'book', 'uploaded_by', 'uploaded_at', 'image')
    search_fields = ('book__title', 'uploaded_by__username')
    list_filter = ('uploaded_at', 'book')






