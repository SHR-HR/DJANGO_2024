default_app_config = 'logs.apps.LogsConfig'
