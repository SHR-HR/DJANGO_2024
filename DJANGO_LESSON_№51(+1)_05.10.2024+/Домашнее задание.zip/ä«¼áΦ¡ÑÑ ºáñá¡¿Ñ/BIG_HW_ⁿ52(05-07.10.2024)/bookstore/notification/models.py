from django.db import models
from django.contrib.auth.models import User

NOTIFICATION_CHOICES = [
    ('user_signup', 'Регистрация пользователя'),
    ('profile_update', 'Изменение профиля'),
    ('password_change', 'Изменение пароля'),
    ('email_change', 'Изменение email'),
    ('user_login', 'Вход пользователя'),
    ('user_logout', 'Выход пользователя'),
    ('profile_delete', 'Удаление профиля'),
]

class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    notification_type = models.CharField(max_length=50, choices=NOTIFICATION_CHOICES)

    class Meta:
        verbose_name = 'Уведомление'
        verbose_name_plural = 'Уведомления'

    def __str__(self):
        return f'Уведомление для {self.user.username} ({self.notification_type})'

class NotificationType(models.Model):
    type_code = models.CharField(max_length=50, unique=True)
    description = models.CharField(max_length=150)

    class Meta:
        verbose_name = 'Тип уведомления'
        verbose_name_plural = 'Типы уведомлений'

    def __str__(self):
        return self.description

class Subscription(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='subscription')
    subscribed_types = models.ManyToManyField(NotificationType, related_name='subscriptions', blank=True)

    class Meta:
        verbose_name = 'Подписка'
        verbose_name_plural = 'Подписки'

    def __str__(self):
        return f'Подписка для {self.user.username}'


