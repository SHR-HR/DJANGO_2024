from rest_framework import serializers
from .models import Notification, Subscription, NotificationType

class NotificationSerializer(serializers.ModelSerializer):
    user = serializers.CharField(source='user.username', read_only=True)

    class Meta:
        model = Notification
        fields = ['id', 'user', 'message', 'created_at', 'notification_type']

class NotificationTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = NotificationType
        fields = ['type_code', 'description']

class SubscriptionSerializer(serializers.ModelSerializer):
    user = serializers.CharField(source='user.username', read_only=True)
    subscribed_types = serializers.SlugRelatedField(
        many=True,
        slug_field='type_code',
        queryset=NotificationType.objects.all(),
        required=False
    )

    class Meta:
        model = Subscription
        fields = ['id', 'user', 'subscribed_types']

    def create(self, validated_data):
        user = self.context['request'].user
        subscription, _ = Subscription.objects.get_or_create(user=user)

        subscription.subscribed_types.set(NotificationType.objects.all())
        subscription.save()
        return subscription




