from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import NotificationViewSet, SubscriptionViewSet

router = DefaultRouter()
router.register(r'notifications', NotificationViewSet, basename='notifications')
router.register(r'subscriptions', SubscriptionViewSet, basename='subscriptions')

urlpatterns = [
    path('', include(router.urls)),
    path('subscriptions/', SubscriptionViewSet.as_view({'get': 'list'}), name='subscriptions-list'),
]


