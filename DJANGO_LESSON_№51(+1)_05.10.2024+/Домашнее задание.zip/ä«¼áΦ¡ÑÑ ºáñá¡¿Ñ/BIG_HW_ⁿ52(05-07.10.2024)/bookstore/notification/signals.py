from django.db.models.signals import pre_save, post_save, post_delete
from django.contrib.auth.models import User
from django.contrib.admin.models import LogEntry
from django.contrib.contenttypes.models import ContentType
from django.dispatch import receiver
from django.core.mail import send_mail
from django.contrib.auth.signals import user_logged_in, user_logged_out
from django.conf import settings
from .models import Notification, NotificationType, Subscription

@receiver(pre_save, sender=User)
def track_profile_update(sender, instance, **kwargs):
    try:
        previous_instance = User.objects.get(pk=instance.pk)
    except User.DoesNotExist:
        previous_instance = None

    changes = []

    if previous_instance:
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in ['last_login', 'date_joined']:
                continue

            old_value = getattr(previous_instance, field_name, None) or ""
            new_value = getattr(instance, field_name, None) or ""

            if old_value != new_value:
                if field_name == "password":
                    changes.append(f"Пароль был изменен.")
                else:
                    changes.append(f"{field.verbose_name}: ({old_value}) → ({new_value})")

    changes_report = "\n".join(changes) if changes else "Изменений не обнаружено."

    if changes:

        notification = create_notification(
            instance, 
            'profile_update', 
            f'Профиль пользователя {instance.username} был обновлен. Изменения:\n{changes_report}'
        )

        LogEntry.objects.log_action(
            user_id=instance.pk,
            content_type_id=ContentType.objects.get_for_model(instance).pk,
            object_id=instance.pk,
            object_repr=str(instance),
            action_flag=2,
            change_message=f"Изменения:\n{changes_report}"
        )

        send_email(
            subject='Детализированное уведомление об изменении профиля пользователя',
            message=f"Пользователь {instance.username} обновил свой профиль. Изменения:\n{changes_report}",
            notification=notification
        )

@receiver(post_delete, sender=User)
def track_profile_deletion(sender, instance, **kwargs):
    notification = create_notification(
        instance, 
        'profile_delete', 
        f'Пользователь {instance.username} был удален.'
    )

    LogEntry.objects.log_action(
        user_id=instance.pk,
        content_type_id=ContentType.objects.get_for_model(instance).pk,
        object_id=instance.pk,
        object_repr=str(instance),
        action_flag=3,
        change_message=f"Пользователь {instance.username} был удален."
    )

    send_email(
        subject='Уведомление об удалении пользователя',
        message=f"Пользователь {instance.username} был удален из системы.",
        notification=notification
    )

@receiver(user_logged_in)
def track_user_login(sender, request, user, **kwargs):
    notification = create_notification(
        user, 
        'user_login', 
        f'Пользователь {user.username} вошел в систему.'
    )
    send_email(
        subject='Уведомление о входе пользователя',
        message=f"Пользователь {user.username} вошел в систему.",
        notification=notification
    )

@receiver(user_logged_out)
def track_user_logout(sender, request, user, **kwargs):
    notification = create_notification(
        user, 
        'user_logout', 
        f'Пользователь {user.username} вышел из системы.'
    )
    send_email(
        subject='Уведомление о выходе пользователя',
        message=f"Пользователь {user.username} вышел из системы.",
        notification=notification
    )

def create_notification(user, notification_type, message):

    if Subscription.objects.filter(user=user, subscribed_types__type_code=notification_type).exists():
        return Notification.objects.create(
            user=user,
            message=message,
            notification_type=notification_type
        )

def send_email(subject, message, notification):

    send_mail(
        subject=subject,
        message=message,
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[admin[1] for admin in settings.ADMINS],
        fail_silently=False,
    )

@receiver(post_save, sender=NotificationType)
def add_new_type_to_all_subscriptions(sender, instance, created, **kwargs):
    if created:

        for subscription in Subscription.objects.all():
            subscription.subscribed_types.add(instance)

