from rest_framework import viewsets, permissions, mixins
from rest_framework.response import Response
from .models import Notification, Subscription
from .serializers import NotificationSerializer, SubscriptionSerializer

class NotificationViewSet(viewsets.ModelViewSet):
    serializer_class = NotificationSerializer
    queryset = Notification.objects.all()
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user

        if user.username == 'IAMSUPERUZZZER':
            return Notification.objects.all()
        return Notification.objects.filter(user=user)

class SubscriptionViewSet(mixins.UpdateModelMixin,
                          mixins.RetrieveModelMixin,
                          mixins.ListModelMixin,
                          viewsets.GenericViewSet):
    queryset = Subscription.objects.all()
    serializer_class = SubscriptionSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        return Subscription.objects.get_or_create(user=self.request.user)[0]
    

