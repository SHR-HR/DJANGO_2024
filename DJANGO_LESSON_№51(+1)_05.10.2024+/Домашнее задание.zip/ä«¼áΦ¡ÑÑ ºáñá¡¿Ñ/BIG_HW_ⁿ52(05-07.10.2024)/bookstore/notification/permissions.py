from rest_framework import permissions

class IsAdminOrModerator(permissions.BasePermission):

    def has_permission(self, request, view):
        return request.user and (request.user.is_staff or request.user.groups.filter(name='Модераторы').exists())

    def has_object_permission(self, request, view, obj):
        if request.user.is_staff:
            return True
        if request.user.groups.filter(name='Модераторы').exists():
            return obj.user.is_staff is False or obj.user == request.user
        return False

