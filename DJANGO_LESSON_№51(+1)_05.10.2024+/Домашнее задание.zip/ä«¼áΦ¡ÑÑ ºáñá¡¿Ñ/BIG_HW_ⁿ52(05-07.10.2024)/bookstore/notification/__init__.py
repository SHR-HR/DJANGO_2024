default_app_config = 'notification.apps.NotificationConfig'



