from django.contrib import admin
from .models import Notification, Subscription, NotificationType

@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'message', 'created_at', 'notification_type')
    search_fields = ('user__username', 'message')
    list_filter = ('notification_type', 'created_at')

@admin.register(Subscription)
class SubscriptionAdmin(admin.ModelAdmin):
    list_display = ('user',)
    search_fields = ('user__username',)

@admin.register(NotificationType)
class NotificationTypeAdmin(admin.ModelAdmin):
    list_display = ('type_code', 'description')
    search_fields = ('type_code', 'description')

