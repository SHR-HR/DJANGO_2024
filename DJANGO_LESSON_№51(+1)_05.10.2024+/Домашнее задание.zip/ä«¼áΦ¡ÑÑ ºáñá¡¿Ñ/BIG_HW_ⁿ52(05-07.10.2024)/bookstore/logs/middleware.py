import logging
from django.utils.deprecation import MiddlewareMixin

logger = logging.getLogger('users')

class UserActionLoggingMiddleware(MiddlewareMixin):
    def process_request(self, request):
        user = request.user
        if user.is_authenticated:
            logger.info(f'Пользователь {user.username} перешел на {request.path} методом {request.method} с IP {request.META.get("REMOTE_ADDR")}')
        else:
            logger.info(f'Анонимный пользователь перешел на {request.path} методом {request.method} с IP {request.META.get("REMOTE_ADDR")}')

    def process_response(self, request, response):
        if request.user.is_authenticated:
            logger.info(f'Пользователь {request.user.username} получил ответ {response.status_code} на {request.path}')
        else:
            logger.info(f'Анонимный пользователь получил ответ {response.status_code} на {request.path}')
        return response
