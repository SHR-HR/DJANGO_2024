import logging

user_logger = logging.getLogger('users')

def log_user_creation(username):
    user_logger.info(f'Пользователь создан: {username}')

def log_user_deletion(username):
    user_logger.warning(f'Пользователь удален: {username}')

def log_user_login(username, ip_address):
    user_logger.info(f'Пользователь {username} вошел в систему с IP: {ip_address}')

def log_user_logout(username, ip_address):
    user_logger.info(f'Пользователь {username} вышел из системы с IP: {ip_address}')

def log_book_action(action, book_title, username):
    user_logger.info(f'{username} выполнил действие: {action} для книги: {book_title}')

def log_image_upload(book_title, username):
    user_logger.info(f'{username} загрузил изображение для книги: {book_title}')

def log_profile_update(username, changes):
    user_logger.info(f'Профиль пользователя {username} был изменен. Изменения: {changes}')





