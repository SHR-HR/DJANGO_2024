from django.db.models.signals import post_save, pre_delete
from django.dispatch import receiver
from django.contrib.auth.models import User
from books.models import Book
from images.models import Image
from .handlers.user_actions_handler import (
    log_user_creation, log_user_deletion, log_profile_update,
    log_book_action, log_image_upload
)

@receiver(post_save, sender=User)
def user_created_handler(sender, instance, created, **kwargs):
    if created:
        log_user_creation(instance.username)

@receiver(pre_delete, sender=User)
def user_deleted_handler(sender, instance, **kwargs):
    log_user_deletion(instance.username)

@receiver(post_save, sender=User)
def user_profile_update_handler(sender, instance, created, **kwargs):
    if not created:
        changes = ', '.join([f'{field}: {value}' for field, value in kwargs.items()])
        log_profile_update(instance.username, changes)

@receiver(post_save, sender=Book)
def book_action_handler(sender, instance, created, **kwargs):
    action = 'создание' if created else 'обновление'
    log_book_action(action, instance.title, instance.author)

@receiver(post_save, sender=Image)
def image_upload_handler(sender, instance, created, **kwargs):
    if created:
        log_image_upload(instance.book.title, instance.uploaded_by.username)





