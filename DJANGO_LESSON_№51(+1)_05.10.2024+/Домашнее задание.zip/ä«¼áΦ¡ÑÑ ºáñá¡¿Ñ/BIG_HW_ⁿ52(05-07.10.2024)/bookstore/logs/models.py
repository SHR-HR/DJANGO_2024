import logging
from django.db.models.signals import post_save, pre_delete
from django.contrib.auth.models import User
from django.dispatch import receiver
from .handlers.user_actions_handler import log_user_creation, log_user_deletion

@receiver(post_save, sender=User)
def track_user_creation(sender, instance, created, **kwargs):
    if created:
        log_user_creation(instance.username)

@receiver(pre_delete, sender=User)
def track_user_deletion(sender, instance, **kwargs):
    log_user_deletion(instance.username)

logger = logging.getLogger('users')
logger.info("Тестовое сообщение о логировании уровня INFO.")
logger.error("Тестовое сообщение об ошибке для проверки отправки почты.")

