from django.urls import path
from django.contrib.auth.views import LoginView, LogoutView
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('profile/', views.profile, name='profile'),
    path('register/', views.register, name='register'),
    path('login/', LoginView.as_view(template_name='users/login.html'), name='login'),
    path('logout/', LogoutView.as_view(template_name='users/logged_out.html'), name='logout'),
    path('change_password/', views.change_password, name='change_password'),
    path('admin_view/', views.admin_view, name='admin_view'),
    path('change_group/<str:username>/<str:group_name>/', views.change_group, name='change_group'),
]
