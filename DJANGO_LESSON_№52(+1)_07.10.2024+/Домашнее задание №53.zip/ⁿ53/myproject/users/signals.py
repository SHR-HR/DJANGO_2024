from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType
from django.db.models.signals import post_migrate, post_save
from django.dispatch import receiver
from django.contrib.auth import get_user_model

User = get_user_model()

@receiver(post_migrate)
def create_user_groups(sender, **kwargs):
    admin_group, created = Group.objects.get_or_create(name='Admin')
    user_group, created = Group.objects.get_or_create(name='User')

    permissions = Permission.objects.all()
    for permission in permissions:
        admin_group.permissions.add(permission)

    view_permission = Permission.objects.filter(codename__startswith='view')
    for permission in view_permission:
        user_group.permissions.add(permission)

    print("Группы Admin и User успешно созданы и настроены.")

@receiver(post_save, sender=User)
def add_user_to_group(sender, instance, created, **kwargs):
    if created:
        if not instance.is_superuser:

            user_group = Group.objects.get(name='User')
            instance.groups.add(user_group)
        else:

            admin_group = Group.objects.get(name='Admin')
            instance.groups.add(admin_group)





