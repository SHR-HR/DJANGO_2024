from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from .forms import RegistrationForm
from django.contrib.auth import logout
from django.contrib.auth.views import LoginView
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from .forms import CustomPasswordChangeForm
from django.http import HttpResponseForbidden
from django.contrib.auth.models import User, Group, Permission
from django.contrib.auth import get_user_model
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response


User = get_user_model()

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Аккаунт для {username} успешно создан! Теперь вы можете войти.')
            return redirect('login')
    else:
        form = RegistrationForm()
    return render(request, 'users/register.html', {'form': form})

def home(request):
    return render(request, 'users/home.html')

@login_required
def profile(request):
    return render(request, 'users/profile.html')

def custom_logout(request):

    if request.method == "GET":
        logout(request)
        return redirect('login')

def user_login(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, "Неверное имя пользователя или пароль")
    return render(request, 'users/login.html')

@login_required
def change_password(request):
    if request.method == 'POST':
        form = CustomPasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'Ваш пароль успешно изменен!')
            return redirect('profile')
        else:
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        form = CustomPasswordChangeForm(request.user)
    return render(request, 'users/change_password.html', {'form': form})

from django.contrib.auth.decorators import user_passes_test

def admin_check(user):
    return user.groups.filter(name='Admin').exists()

@user_passes_test(admin_check, login_url='home')
def admin_view(request):
    return render(request, 'users/admin_view.html')

@login_required
def change_group(request, username, group_name):
    try:

        user = User.objects.get(username=username)
        
        group = Group.objects.get(name=group_name)
        
        user.groups.clear()
        user.groups.add(group)
        
        user.save()
        
        messages.success(request, f"Пользователь {user.username} был добавлен в группу {group.name}.")
    except User.DoesNotExist:
        messages.error(request, f"Пользователь {username} не найден.")
    except Group.DoesNotExist:
        messages.error(request, f"Группа {group_name} не существует.")
    
    return redirect('home')

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def profile_api(request):
    user = request.user
    return Response({
        'username': user.username,
        'email': user.email,
        'groups': [group.name for group in user.groups.all()]
    })


