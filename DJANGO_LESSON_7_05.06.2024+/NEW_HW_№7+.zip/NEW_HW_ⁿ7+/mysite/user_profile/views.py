# user_profile/views.py
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import UserProfile

def user_profile(request):
    profile, created = UserProfile.objects.get_or_create(user=request.user)
    return render(request, 'user_profile/profile.html', {'profile': profile})
