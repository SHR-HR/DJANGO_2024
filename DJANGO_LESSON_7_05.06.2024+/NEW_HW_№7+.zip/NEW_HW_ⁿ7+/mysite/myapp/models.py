from django.db import models
from django.conf import settings
from django.core.exceptions import ValidationError

def validate_positive(value):
    if value < 0:
        raise ValidationError('This field must be zero or positive.')

def validate_positive_and_max_value(value, max_value=10000):
    if value < 0 or value > max_value:
        raise ValidationError(f'The value must be between 0 and {max_value}.')

class Product(models.Model):
    name = models.CharField(max_length=255)
    category = models.CharField(max_length=100)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2, validators=[validate_positive_and_max_value])
    image = models.ImageField(upload_to='products/')

    def display_id_and_price(self):
        return f"ID: {self.id}, Price: {self.price}"

    def display_product_with_price(self):
        return f"ID {self.id}: {self.name} at price {self.price}"

    def price_with_tax(self, tax_rate=0.1):
        """Calculate the price with a given tax rate."""
        return self.price + self.price * tax_rate

    def formatted_price(self):
        """Return the price formatted as a string with two decimal places."""
        return "{:.2f} тг.".format(self.price)

    def __str__(self):
        return f"{self.name} ({self.category}) - {self.price}"

class Feedback(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback from {self.user.username if self.user else 'Anonymous'} on {self.created_at}"
