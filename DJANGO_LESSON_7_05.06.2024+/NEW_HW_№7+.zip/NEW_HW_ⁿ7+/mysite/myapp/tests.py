from django.test import TestCase
from .models import Product
from django.core.exceptions import ValidationError

class ProductModelTest(TestCase):
    def test_display_id_and_price(self):
        product = Product.objects.create(name="Test", category="Test", description="Test description", price=100)
        self.assertEqual(product.display_id_and_price(), f"ID: {product.id}, Price: {product.price}")

    def test_validate_positive(self):
        product = Product(name="Test", category="Test", description="Test description", price=-10)
        with self.assertRaises(ValidationError):
            product.full_clean()
