from django.contrib import admin
from .models import Feedback
from .models import Product  # Импортируйте вашу модель

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'price', 'description']  # Поля, которые вы хотите видеть в списке
    search_fields = ['name', 'category']  # Поля, по которым можно искать
    list_filter = ['category', 'price']  # Поля, по которым можно фильтровать

@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ['message', 'user', 'created_at']


