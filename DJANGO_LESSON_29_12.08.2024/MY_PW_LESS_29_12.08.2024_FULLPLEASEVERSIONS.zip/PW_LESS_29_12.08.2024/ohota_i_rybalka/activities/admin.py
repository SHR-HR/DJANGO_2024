from django.contrib import admin
from .models import Location, Activity

admin.site.register(Location)
admin.site.register(Activity)




