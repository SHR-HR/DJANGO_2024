from django.db import models
from django.contrib.auth.models import User

class Location(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    image_url = models.URLField(max_length=200, null=True, blank=True)

    def __str__(self):
        return self.name

class Species(models.Model):
    TYPE_CHOICES = [
        ('Охота', 'Охота'),
        ('Рыбалка', 'Рыбалка'),
    ]

    name = models.CharField(max_length=100)
    species_type = models.CharField(max_length=50, choices=TYPE_CHOICES)

    def __str__(self):
        return f'{self.name} ({self.species_type})'

class Season(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name

class Activity(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(null=True, blank=True)
    rating = models.IntegerField(null=True, blank=True)
    difficulty = models.CharField(max_length=50, null=True, blank=True)
    locations = models.ManyToManyField(Location, related_name='activities')
    species = models.ManyToManyField(Species, related_name='activities')
    season = models.ForeignKey(Season, on_delete=models.CASCADE, related_name='activities', default=1)
    participants = models.ManyToManyField(User, related_name='activities')
    date = models.DateField()

    def __str__(self):
        return f'{self.name} on {self.date}'


