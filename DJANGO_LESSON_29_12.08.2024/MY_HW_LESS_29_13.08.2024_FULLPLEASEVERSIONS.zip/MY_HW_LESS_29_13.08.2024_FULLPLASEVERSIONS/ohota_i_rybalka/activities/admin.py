from django.contrib import admin
from .models import Location, Activity, Species, Season

admin.site.register(Location)
admin.site.register(Activity)
admin.site.register(Species)
admin.site.register(Season)


