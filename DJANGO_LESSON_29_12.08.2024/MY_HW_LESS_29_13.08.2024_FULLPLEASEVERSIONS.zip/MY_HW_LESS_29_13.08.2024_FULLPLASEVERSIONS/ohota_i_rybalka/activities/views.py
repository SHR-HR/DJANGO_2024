from django.shortcuts import render, get_object_or_404
from activities.models import Activity, Season, Location, User
from django.core.paginator import Paginator
from django.db.models import Count

def activity_view(request):
    season_name = request.GET.get('season')
    location_name = request.GET.get('location')
    user_name = request.GET.get('user')
    activity_id = request.GET.get('id')
    keyword = request.GET.get('keyword')
    min_participants = request.GET.get('min_participants')
    sort_by = request.GET.get('sort_by', 'date')
    page_number = request.GET.get('page', 1)

    try:
        activities = Activity.objects.all()

        if season_name:
            season = get_object_or_404(Season, name__iexact=season_name)
            activities = activities.filter(season=season)

        if location_name:
            location = get_object_or_404(Location, name__iexact=location_name)
            activities = activities.filter(locations=location)

        if user_name:
            user = get_object_or_404(User, username__iexact=user_name)
            activities = activities.filter(participants=user)

        if keyword:
            activities = activities.filter(name__icontains=keyword)

        if min_participants:
            activities = activities.annotate(num_participants=Count('participants')).filter(num_participants__gte=min_participants)

        if sort_by == 'name':
            activities = activities.order_by('name')
        else:
            activities = activities.order_by('date')

        paginator = Paginator(activities, 10)
        activities = paginator.get_page(page_number)

        total_activities = Activity.objects.count()
        total_participants = User.objects.count()

        if activity_id:
            activity = get_object_or_404(Activity, id=activity_id)
            return render(request, 'activities/activity_detail.html', {'activity': activity})

        return render(request, 'activities/activity_list.html', {
            'activities': activities,
            'total_activities': total_activities,
            'total_participants': total_participants
        })

    except Exception as e:
        return render(request, 'activities/activity_list.html', {'error': str(e)})




def activity_simple_list_view(request):
    activities = Activity.objects.values('name', 'date')
    return render(request, 'activities/activity_simple_list.html', {'activities': activities})



