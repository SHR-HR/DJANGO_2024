from django.urls import path
from . import views

urlpatterns = [
    path('', views.activity_view, name='activity_list'),
    path('extended/<int:pk>/', views.extended_activity_detail_view, name='extended_activity_detail'),
    path('high-rated/', views.high_rated_activities_view, name='high_rated_activities'),
    path('simple/', views.activity_simple_list_view, name='activity_simple_list'),
    path('premium/', views.premium_activity_list_view, name='premium_activity_list'),
    path('cancel-transaction/', views.cancel_transaction_example, name='cancel_transaction'),
]



