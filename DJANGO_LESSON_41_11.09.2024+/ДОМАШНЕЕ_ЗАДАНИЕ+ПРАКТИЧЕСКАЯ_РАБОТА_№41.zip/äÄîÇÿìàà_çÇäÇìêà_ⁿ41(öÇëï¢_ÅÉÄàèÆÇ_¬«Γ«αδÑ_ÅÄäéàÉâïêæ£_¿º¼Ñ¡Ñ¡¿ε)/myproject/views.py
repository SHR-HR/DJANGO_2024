from django.shortcuts import render, redirect
from amenities.models import Amenity
from rooms.models import Room
from supermarket.models import SupermarketItem
# Импорт всего необходимого в рамках выполнения Домашнего задания №41
from django.contrib import messages
from django.core import signing
from django.contrib.auth.models import User

# Функция для отображения главной страницы с данными из моделей
def home(request):
    amenities = Amenity.objects.all()
    rooms = Room.objects.all()
    supermarket_items = SupermarketItem.objects.all()
    
    return render(request, 'main.html', {
        'amenities': amenities,
        'rooms': rooms,
        'supermarket_items': supermarket_items,
    })

# Функция для отображения успешного сообщения
def my_view(request):
    # Получаем пользователя для подписания данных
    try:
        user = User.objects.get(username='testuser0')
    except User.DoesNotExist:
        user = None

    # Если пользователь найден, создаем данные для подписи
    if user:
        data = {
            'username': user.username,
            'email': user.email
        }
        signed_data = signing.dumps(data)
        try:
            original_data = signing.loads(signed_data)
        except signing.BadSignature:
            original_data = None
    else:
        signed_data = None
        original_data = None

    # Добавляем всплывающее сообщение
    messages.success(request, 'Ваше сообщение успешно отправлено!')

    # Передаем подписанные и оригинальные данные в шаблон
    return render(request, 'main.html', {
        'signed_data': signed_data,
        'original_data': original_data,
        'amenities': Amenity.objects.all(),
        'rooms': Room.objects.all(),
        'supermarket_items': SupermarketItem.objects.all(),
    })

# Функция для отображения важного сообщения
def important_message_view(request):
    # Получаем пользователя для подписания данных
    try:
        user = User.objects.get(username='testuser0')
    except User.DoesNotExist:
        user = None

    # Если пользователь найден, создаем данные для подписи
    if user:
        data = {
            'username': user.username,
            'email': user.email
        }
        signed_data = signing.dumps(data)
        try:
            original_data = signing.loads(signed_data)
        except signing.BadSignature:
            original_data = None
    else:
        signed_data = None
        original_data = None

    # Добавляем важное сообщение
    messages.add_message(request, 50, 'Это важное сообщение об выполнении Домашнего Задания №41!')

    # Передаем подписанные и оригинальные данные в шаблон
    return render(request, 'main.html', {
        'signed_data': signed_data,
        'original_data': original_data,
        'amenities': Amenity.objects.all(),
        'rooms': Room.objects.all(),
        'supermarket_items': SupermarketItem.objects.all(),
    })

# А здесь добавил новую функцию в рамках выполнения домашнего задания №41.2
def sign_data_view(request):
    # Проверим, есть ли в базе нужный пользователь
    try:
        user = User.objects.get(username='testuser0')
    except User.DoesNotExist:
        user = None

    # Если пользователь найден, создаем данные для подписи
    if user:
        data = {
            'username': user.username,
            'email': user.email
        }

        # Подписываем данные
        signed_data = signing.dumps(data)

        # Декодируем данные для проверки
        try:
            original_data = signing.loads(signed_data)
        except signing.BadSignature:
            original_data = None
    else:
        signed_data = None
        original_data = None

    # И передаем подписанные и оригинальные данные в шаблон
    return render(request, 'main.html', {
        'signed_data': signed_data,
        'original_data': original_data,
        'amenities': Amenity.objects.all(),
        'rooms': Room.objects.all(),
        'supermarket_items': SupermarketItem.objects.all()
    })



