from django.urls import path, include
from django.contrib import admin
from django.shortcuts import redirect

def redirect_to_app(request):
    return redirect('/myapp/')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('myapp/', include('myapp.urls')),
    path('', redirect_to_app, name='redirect_to_app'),
]
