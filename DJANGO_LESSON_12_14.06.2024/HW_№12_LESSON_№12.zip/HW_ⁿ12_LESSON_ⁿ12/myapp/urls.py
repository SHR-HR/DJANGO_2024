from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('select/', views.select_columns, name='select_columns'),
    path('exclude/', views.exclude_values, name='exclude_values'),
]