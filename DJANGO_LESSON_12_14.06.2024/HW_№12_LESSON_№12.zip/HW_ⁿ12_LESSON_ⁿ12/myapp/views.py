from django.http import JsonResponse, HttpResponse
from .models import Person

def home(request):
    return HttpResponse("ВелCOME ту ZE хоум Пэйдж - Дз-шки 12")

def select_columns(request):
    
    data = Person.objects.values('name', 'city')
    return JsonResponse(list(data), safe=False)

def exclude_values(request):
    
    data = Person.objects.exclude(city='Karaganda').values()
    return JsonResponse(list(data), safe=False)
