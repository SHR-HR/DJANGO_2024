# E:\001PROJ\mysite\user_support\urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('support_tickets/', views.support_tickets, name='support_tickets'),
    path('tickets/<int:ticket_id>/', views.ticket_detail, name='detail_view'),
    path('tickets/<int:ticket_id>/delete', views.ticket_delete, name='delete_view'),
    # Другие URL-адреса для приложения user_support
]
