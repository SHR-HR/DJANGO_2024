from django import template
from django.contrib.auth.models import Group

register = template.Library()

@register.filter(name='is_manager_or_admin')
def is_manager_or_admin(user):
    return user.is_superuser or Group.objects.get(name='Менеджеры') in user.groups.all()
