# E:\001PROJ\mysite\user_support\views.py
# user_support/views.py
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .models import SupportTicket
from .forms import SupportTicketForm

# Проверка, является ли пользователь менеджером или администратором
def is_manager_or_admin(user):
    return user.is_superuser or user.groups.filter(name='Менеджеры').exists()

@login_required
def support_tickets(request):
    if request.method == 'POST':
        form = SupportTicketForm(request.POST)
        if form.is_valid():
            ticket = form.save(commit=False)
            ticket.user = request.user
            ticket.save()
            return redirect('support_tickets')  # Перенаправление после отправки формы
    else:
        form = SupportTicketForm()

    if is_manager_or_admin(request.user):  # Для админов и менеджеров
        tickets = SupportTicket.objects.all()
    else:  # Обычные пользователи видят только свои заявки
        tickets = SupportTicket.objects.filter(user=request.user)

    return render(request, 'user_support/support_tickets.html', {'form': form, 'tickets': tickets})

@login_required
def ticket_detail(request, ticket_id):
    ticket = get_object_or_404(SupportTicket, id=ticket_id)
    if is_manager_or_admin(request.user):
        return render(request, 'user_support/ticket_detail.html', {'ticket': ticket})
    else:
        return HttpResponse('У вас нет прав для просмотра этой страницы', status=403)

@login_required
def ticket_delete(request, ticket_id):
    ticket = get_object_or_404(SupportTicket, id=ticket_id)
    if request.user.is_superuser:  # Только администратор может удалять заявки
        ticket.delete()
        return redirect('support_tickets')
    else:
        return HttpResponse('У вас нет прав для выполнения этой операции', status=403)
