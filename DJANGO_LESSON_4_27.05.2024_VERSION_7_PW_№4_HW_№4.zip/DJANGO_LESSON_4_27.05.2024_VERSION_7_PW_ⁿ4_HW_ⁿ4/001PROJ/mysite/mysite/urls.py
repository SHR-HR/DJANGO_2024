from django.contrib import admin
from django.urls import path, include
from myapp.views import admin_dashboard  # Импортируйте функцию admin_dashboard напрямую
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('admin/dashboard/', admin_dashboard, name='admin_dashboard'),  # Путь к вашему представлению admin_dashboard
    path('', include('myapp.urls')),
    path('profile/', include('user_profile.urls')),
    path('support/', include('user_support.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
