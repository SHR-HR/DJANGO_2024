from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404, redirect
from .forms import FeedbackForm, RegistrationForm
from .models import Product, Feedback
from user_support.models import SupportTicket
from django.contrib.auth.models import User

def index(request):
    products = Product.objects.all()
    return render(request, 'myapp/index.html', {'products': products})

def about(request):
    return render(request, 'myapp/about.html')

def products(request):
    food_products = Product.objects.filter(category='Продукты питания')
    return render(request, 'myapp/products.html', {'products': food_products})

def household(request):
    household_products = Product.objects.filter(category='Бытовая химия')
    return render(request, 'myapp/household.html', {'products': household_products})

def add_product(request):
    if request.method == 'POST':
        name = request.POST['name']
        category = request.POST['category']
        description = request.POST['description']
        price = request.POST['price']
        image = request.FILES['image']
        product = Product(name=name, category=category, description=description, price=price, image=image)
        product.save()
        return redirect('index')
    return render(request, 'myapp/add_product.html')

def product_detail(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    return render(request, 'myapp/product_detail.html', {'product': product})

def feedback_view(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            feedback = form.save(commit=False)
            if request.user.is_authenticated:
                feedback.user = request.user
            feedback.save()
            return redirect('index')
    else:
        form = FeedbackForm()
    return render(request, 'feedback_form.html', {'form': form})

def archive(request, year):
    return render(request, 'myapp/archive.html', {'year': year})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f'Добро пожаловать, {username}!')
                return redirect('index')
            else:
                messages.error(request, 'Неверное имя пользователя или пароль.')
        else:
            messages.error(request, 'Неверное имя пользователя или пароль.')
    else:
        form = AuthenticationForm()
    return render(request, 'myapp/login.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.success(request, 'Вы успешно вышли из системы.')
    return redirect('index')

def admin_dashboard(request):
    if not request.user.is_superuser:
        return HttpResponse('Доступ запрещен', status=403)

    feedbacks = Feedback.objects.all()
    support_tickets = SupportTicket.objects.all()
    return render(request, 'myapp/admin_dashboard.html', {
        'feedbacks': feedbacks,
        'support_tickets': support_tickets,
    })

def contact(request):
    return render(request, 'myapp/contact.html')

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            login(request, user)
            return redirect('index')
    else:
        form = RegistrationForm()
    return render(request, 'myapp/register.html', {'form': form})