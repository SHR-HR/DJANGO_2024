from django.urls import path, re_path
from . import views
from myapp import views
from .views import feedback_view, login_view, logout_view, register

urlpatterns = [
    path('', views.index, name='index'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('products/', views.products, name='products'),
    path('household/', views.household, name='household'),
    path('add_product/', views.add_product, name='add_product'),
    path('product/<int:product_id>/', views.product_detail, name='product_detail'),
    path('feedback/', views.feedback_view, name='feedback'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', register, name='register'),
    re_path(r'^archive/(?P<year>[0-9]{4})/$', views.archive, name='archive'),
]
