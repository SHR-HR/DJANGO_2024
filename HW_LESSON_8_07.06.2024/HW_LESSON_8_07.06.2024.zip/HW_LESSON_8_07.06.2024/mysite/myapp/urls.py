# myapp/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # Главная страница
    path('regex/', views.regex_test, name='regex_test'),  # Обработчик для регулярных выражений
]
