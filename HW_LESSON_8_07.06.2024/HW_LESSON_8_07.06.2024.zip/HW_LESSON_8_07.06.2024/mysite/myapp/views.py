from django.http import HttpResponse
import re
from django.shortcuts import render

def home(request):
    return render(request, 'myapp/home.html')

def regex_test(request):
    text_to_search = request.GET.get('text', '')
    if not text_to_search:
        return HttpResponse("Пожалуйста, введите текст для анализа.")

    phone_regex = r'\+?\d{1,3}[-\s]?\d{1,3}[-\s]?\d{1,4}[-\s]?\d{1,4}'
    email_regex = r'\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b'
    hashtag_regex = r'\B#\w+'

    phones = re.findall(phone_regex, text_to_search)
    emails = re.findall(email_regex, text_to_search)
    hashtags = re.findall(hashtag_regex, text_to_search)

    response = f"Найденные номера телефонов: {phones}\nНайденные адреса электронной почты: {emails}\nНайденные хештеги: {hashtags}"
    return HttpResponse(response)
