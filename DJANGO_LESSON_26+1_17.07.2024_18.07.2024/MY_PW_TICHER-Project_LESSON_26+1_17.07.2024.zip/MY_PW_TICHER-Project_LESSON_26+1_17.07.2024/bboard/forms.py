from django import forms
from django.forms import modelformset_factory
from django.contrib.auth.models import User
from .models import Bb, Rubric

class BbForm(forms.ModelForm):
    title = forms.CharField(label='Товар', help_text='Введите название товара')
    content = forms.CharField(label='Описание', widget=forms.Textarea, help_text='Введите описание товара')
    price = forms.DecimalField(label='Цена', decimal_places=2, help_text='Введите цену товара')
    rubric = forms.ModelChoiceField(queryset=Rubric.objects.all(), label='Рубрика', help_text='Выберите рубрику товара')

    class Meta:
        model = Bb
        fields = ('title', 'content', 'price', 'rubric')

    def clean_title(self):
        val = self.cleaned_data.get('title')
        if val == "Прошлогодний снег":
            raise forms.ValidationError('К продаже не допускается')
        return val

    def clean(self):
        super().clean()
        errors = {}
        if not self.cleaned_data.get('content'):
            errors['content'] = forms.ValidationError('Укажите описание продаваемого товара')
        if self.cleaned_data.get('price', 0) < 0:
            errors['price'] = forms.ValidationError('Укажите неотрицательное значение цены')
        if errors:
            raise forms.ValidationError(errors)

class RegisterUserForm(forms.ModelForm):
    password1 = forms.CharField(label='Пароль', widget=forms.PasswordInput)
    password2 = forms.CharField(label='Повторите пароль', widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2', 'first_name', 'last_name')

    def clean_password2(self):
        password1 = self.cleaned_data.get('password1')
        password2 = self.cleaned_data.get('password2')
        if password1 and password2 and password1 != password2:
            raise forms.ValidationError("Пароли не совпадают")
        return password2

RubricFormSet = modelformset_factory(Rubric, fields=('name',), can_order=True, can_delete=True)
BbFormSet = modelformset_factory(Bb, form=BbForm, extra=1, can_delete=True)

