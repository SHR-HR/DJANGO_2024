from django.urls import path, re_path
from .views import (index, by_rubric, BbCreateView, get_comments, get_comment_by_id, delete_comment, 
                    add_and_save, redirect_to_index, detail, redirect_to_rubric, BbByRubricView, BbDetailView, BbAddView, BbEditView, BbDeleteView, BbIndexView, BbMonthArchiveView,
                    BbRedirectView, UserCreate, edit, rubric_view, bbs, manage_bbs)
from .models import Bb

app_name = 'bboard'

urlpatterns = [
    path('comments/', get_comments, name='get_comments'),
    path('comments/<int:comment_id>/', get_comment_by_id, name='get_comment_by_id'),
    path('comments/delete/<int:comment_id>/', delete_comment, name='delete_comment'),
    path('rubrics/', rubric_view, name='rubric_view'),
    path('add/', BbCreateView.as_view(), name='add'),
    path('create/', UserCreate.as_view(), name='create'),
    path('edit/<int:pk>/', edit, name='edit'),
    path('delete/<int:pk>/', BbDeleteView.as_view(), name='delete'),
    path('<int:year>/<int:month>/<int:day>', BbMonthArchiveView.as_view(), name='month_archive'),
    path('bbs/<int:rubric_id>/', bbs, name='bbs'),
    path('<int:rubric_id>/', BbByRubricView.as_view(), name='by_rubric'),
    path('manage/', manage_bbs, name='manage_bbs'),
    path('', index, name='index'),
    path('redirect/', redirect_to_index, name='redirect_to_index'),
    path('detail/<int:pk>/', BbDetailView.as_view(), name='detail'),
    path('redirect/<int:rubric_id>/', redirect_to_rubric, name='redirect_to_rubric'),
]



