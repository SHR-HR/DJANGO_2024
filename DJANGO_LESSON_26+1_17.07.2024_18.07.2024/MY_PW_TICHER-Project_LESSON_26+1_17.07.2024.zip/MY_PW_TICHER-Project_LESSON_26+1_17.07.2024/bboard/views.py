from django.forms.forms import BaseForm
from django.shortcuts import render, get_object_or_404, redirect, get_list_or_404
from django.http import HttpResponse, JsonResponse, HttpResponseNotFound, HttpResponseRedirect, HttpResponse, HttpResponsePermanentRedirect, Http404, StreamingHttpResponse, FileResponse
from .models import Bb, Rubric, Comment  
from django.template import loader
from .forms import BbForm, RegisterUserForm, RubricFormSet, BbFormSet
from django.forms import modelformset_factory, inlineformset_factory
from django.forms.formsets import ORDERING_FIELD_NAME
from django.urls import reverse_lazy, reverse
from django.template.loader import get_template, render_to_string
from django.views.decorators.http import require_http_methods
from django.views.decorators.gzip import gzip_page
from django.views.generic.base import TemplateView, RedirectView
from django.views.generic.detail import DetailView
from django.views.generic.list import ListView
from django.views.generic.edit import FormView, UpdateView, DeleteView, CreateView
from django.views.generic.dates import ArchiveIndexView, MonthArchiveView, DayArchiveView, DateDetailView
from django.views.generic.detail import SingleObjectMixin
from django.core.paginator import Paginator
from django.forms.models import BaseModelFormSet
from django.core.exceptions import ValidationError

def get_comments(request):
    comments = Comment.objects.all().values('id', 'text', 'created_at')
    return JsonResponse(list(comments), safe=False)

def get_comment_by_id(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    return JsonResponse({'id': comment.id, 'text': comment.text, 'created_at': comment.created_at})

def delete_comment(request, comment_id):
    try:
        comment = Comment.objects.get(id=comment_id)
        comment.delete()
        return JsonResponse({'status': 'success'})
    except Comment.DoesNotExist:
        return HttpResponseNotFound({'status': 'comment not found'})


class UserCreate(CreateView):
    template_name = 'bboard/createuser.html'
    form_class = RegisterUserForm
    success_url = reverse_lazy('bboard:index')

class BbCreateView(CreateView):
    template_name = 'bboard/create.html'
    form_class = BbForm
    success_url = reverse_lazy('bboard:index')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['rubrics'] = Rubric.objects.all()
        return context

def redirect_to_index(request):
    return HttpResponseRedirect(reverse('bboard:index'))

def index(request):
    rubrics = Rubric.objects.all()
    bbs = Bb.objects.all()
    paginator = Paginator(bbs, 2)
    page_num = request.GET.get('page', 1)
    page = paginator.get_page(page_num)
    url1 = reverse('bboard:index')
    context = {'bbs': page.object_list, 'rubrics': rubrics, 'url1': url1, 'page': page}
    return render(request, 'bboard/index.html', context)

def by_rubric(request, rubric_id):
    bbs = Bb.objects.filter(rubric=rubric_id)
    rubrics = Rubric.objects.all()
    current_rubric = Rubric.objects.get(pk=rubric_id)
    url = reverse('bboard:by_rubric', args=(current_rubric.pk,))
    context = {'bbs': bbs, 'rubrics': rubrics, 'current_rubric': current_rubric, 'url': url}
    return render(request, 'bboard/by_rubric.html', context)

def redirect_to_rubric(request, rubric_id):
    return redirect('bboard:by_rubric', rubric_id=rubric_id)

@require_http_methods(['GET', 'POST'])
def add_and_save(request):
    if request.method == 'POST':
        bbf = BbForm(request.POST)
        if bbf.is_valid():
            bbf.save()
            return HttpResponseRedirect(reverse('bboard:by_rubric', kwargs={'rubric_id': bbf.cleaned_data['rubric'].pk}))
        else:
            context = {'form': bbf}
            return render(request, 'bboard/create.html', context)
    else:
        bbf = BbForm()
        context = {'form': bbf}
        return render(request, 'bboard/create.html', context)
    

def detail(request, bb_id):
    bb = get_list_or_404(Bb, pk=bb_id)
    return HttpResponse(f'Название: {bb.title}, Описание: {bb.content}, Дата публикации: {bb.published}')

class BbDetailView(DetailView):
    model = Bb

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['rubrics'] = Rubric.objects.all()
        return context

class BbAddView(FormView):
    template_name = 'bboard/create.html'
    form_class = BbForm
    initial = {'price': 0.0}

    def get_context_data(self, *args, **kwargs):
        context = super().get_context_data(*args, **kwargs)
        context['rubrics'] = Rubric.objects.all()
        return context
    
    def form_valid(self, form):
        form.save()
        return super().form_valid(form)
    
    def get_form(self, form_class=None):
        self.object = super().get_form(form_class)
        return self.object
    
    def get_success_url(self):
        return reverse('bboard:by_rubric', kwargs={'rubric_id': self.object.cleaned_data['rubric'].pk})

class BbEditView(UpdateView):
    model = Bb
    form_class = BbForm
    success_url = '/'

    def get_context_data(self, *args, **kwargs):
        context = super().get_context_data(*args, **kwargs)
        context['rubrics'] = Rubric.objects.all()
        return context

class BbDeleteView(DeleteView):
    model = Bb
    success_url = '/'

    def get_context_data(self,*args, **kwargs):
        context = super().get_context_data(*args, **kwargs)
        context['rubrics'] = Rubric.objects.all()
        return context

class BbIndexView(ArchiveIndexView):
    model = Bb
    date_field = 'published'
    date_list_period = 'year'
    template_name = 'bboard/index.html'
    context_object_name = 'bbs'
    allow_empty = True

    def get_context_data(self, *args, **kwargs):
        context = super().get_context_data(*args, **kwargs)
        context['rubrics'] = Rubric.objects.all()
        context['url1'] = reverse_lazy('bboard:index')
        return context

class BbMonthArchiveView(DayArchiveView):
    model = Bb
    date_field = 'published'
    month_format = '%m'
    template_name = 'bboard/bb_archive_month.html'

class BbRedirectView(RedirectView):
    def get_redirect_url(self, *args, **kwargs):
        return reverse('bboard:detail', kwargs={'pk': self.kwargs['pk']})

class BbByRubricView(SingleObjectMixin, ListView):
    template_name = 'bboard/by_rubric.html'
    pk_url_kwarg = 'rubric_id'   

    def get(self, request, *args, **kwargs):
        self.object = self.get_object(queryset=Rubric.objects.all())
        return super().get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['current_rubric'] = self.object
        context['rubrics'] = Rubric.objects.all()
        context['bbs'] = context['object_list']
        context['ulist'] = ['PHP', ['Python', 'Django'], ['JavaScript', 'Node.js', 'Express']]
        return context
    
    def get_queryset(self):
        return self.object.bb_set.all()

def edit(request, pk):
    bb = Bb.objects.get(pk=pk)
    if request.method == 'POST':
        bbf = BbForm(request.POST, instance=bb)
        if bbf.is_valid():
            bbf.save()
            return HttpResponseRedirect(reverse('bboard:by_rubric', kwargs={'rubric_id': bbf.cleaned_data['rubric'].pk}))
        else:
            context = {'form': bbf}
            return render(request, 'bboard/bb_form.html', context)
    else:
        bbf = BbForm(instance=bb)
        context = {'form': bbf}
        return render(request, 'bboard/bb_form.html', context)

def rubric_view(request):
    RubricFormSet = modelformset_factory(Rubric, fields=('name',), can_order=True, can_delete=True)
    if request.method == 'POST':
        formset = RubricFormSet(request.POST, queryset=Rubric.objects.all())
        if formset.is_valid():
            formset.save()
            return redirect('bboard:index')
    else:
        formset = RubricFormSet(queryset=Rubric.objects.all())
    return render(request, 'bboard/form.html', {'formset': formset})

def bbs(request, rubric_id):
    BbsFormSet = inlineformset_factory(Rubric, Bb, form=BbForm, extra=1)
    rubric = Rubric.objects.get(pk=rubric_id)
    if request.method == 'POST':
        formset = BbsFormSet(request.POST, instance=rubric)
        if formset.is_valid():
            formset.save()
            return redirect('bboard:index')
    else:
        formset = BbsFormSet(instance=rubric)
    return render(request, 'bboard/bbs.html', {'formset': formset, 'current_rubric': rubric})

def manage_bbs(request):
    if request.method == 'POST':
        formset = BbFormSet(request.POST)
        if formset.is_valid():
            formset.save()
            return redirect('bboard:index')
    else:
        formset = BbFormSet(queryset=Bb.objects.all())
    return render(request, 'bboard/manage_bbs.html', {'formset': formset})

def manage_bbs(request):
    if request.method == 'POST':
        formset = BbFormSet(request.POST)
        if formset.is_valid():
            formset.save()
            return redirect('bboard:index')
    else:
        formset = BbFormSet(queryset=Bb.objects.all())
    return render(request, 'bboard/manage_bbs.html', {'formset': formset})



