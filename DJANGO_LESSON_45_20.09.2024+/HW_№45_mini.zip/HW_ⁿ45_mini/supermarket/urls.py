from django.urls import path
from . import views

urlpatterns = [
    path('list/', views.supermarket_list, name='supermarket_list'),
    path('<int:pk>/', views.supermarket_item_detail, name='supermarket_item_detail'),
    path('<int:pk>/upload_image/', views.upload_supermarket_image, name='upload_supermarket_image'),
    path('<int:pk>/delete_image/', views.delete_supermarket_image, name='delete_supermarket_image'),
    path('<int:pk>/upload_file/', views.supermarket_item_detail, name='upload_supermarket_file'),
    path('<int:pk>/delete_file/', views.supermarket_item_detail, name='delete_supermarket_file'),
]



