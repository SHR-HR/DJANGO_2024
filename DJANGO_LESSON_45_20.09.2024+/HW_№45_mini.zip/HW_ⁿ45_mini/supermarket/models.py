from django.db import models
from localflavor.generic.models import BICField, IBANField

class SupermarketItem(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название товара")
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Цена")
    stock = models.IntegerField(verbose_name="Количество на складе", default=0)
    details = models.JSONField(verbose_name="Детали", blank=True, null=True)
    image = models.ImageField(upload_to='supermarket/', verbose_name="Изображение", blank=True, null=True)
    file = models.FileField(upload_to='supermarket/files/', blank=True, null=True, verbose_name="Документ (xlsx/pdf)")

    class Meta:
        verbose_name = "Товар"
        verbose_name_plural = "Товары"

    def __str__(self):
        return self.name


class EnhancedSupermarketItem(models.Model):
    item = models.ForeignKey(SupermarketItem, on_delete=models.CASCADE, verbose_name="Основной товар")
    country_of_origin = models.CharField(max_length=100, verbose_name="Страна происхождения")
    expiration_date = models.DateField(verbose_name="Срок годности")
    special_offers = models.JSONField(verbose_name="Специальные предложения", blank=True, null=True)
    bic = BICField(verbose_name="BIC код", blank=True, null=True)
    iban = IBANField(verbose_name="IBAN", blank=True, null=True)

    class Meta:
        verbose_name = "Расширенный Товар"
        verbose_name_plural = "Расширенные Товары"

    def __str__(self):
        return f"{self.item.name} - {self.country_of_origin}"

