from django import forms
from .models import SupermarketItem

class SupermarketItemForm(forms.ModelForm):
    class Meta:
        model = SupermarketItem
        fields = ['name', 'price', 'stock', 'details', 'image', 'file']


