from django.shortcuts import render, redirect, get_object_or_404
from .models import SupermarketItem
from django.conf import settings
import os

def supermarket_list(request):
    items = SupermarketItem.objects.all()
    return render(request, 'supermarket_list.html', {'items': items})

def supermarket_item_detail(request, pk):
    item = get_object_or_404(SupermarketItem, pk=pk)
    
    if request.method == "POST":
        if 'image' in request.FILES:
            item.image = request.FILES.get('image')
            item.save()
        elif 'delete_image' in request.POST:
            item.image.delete()
            item.save()
        elif 'file' in request.FILES:
            item.file = request.FILES.get('file')
            item.save()
        elif 'delete_file' in request.POST:
            item.file.delete()
            item.file = None
            item.save()
        return redirect('supermarket_item_detail', pk=pk)

    return render(request, 'supermarket_item_detail.html', {'item': item})

def upload_supermarket_image(request, pk):
    item = get_object_or_404(SupermarketItem, pk=pk)
    if request.method == "POST":
        item.image = request.FILES.get('image')
        item.save()
    return redirect('supermarket_item_detail', pk=pk)

def delete_supermarket_image(request, pk):
    item = get_object_or_404(SupermarketItem, pk=pk)
    if item.image:
        item.image.delete()
        item.save()
    return redirect('supermarket_item_detail', pk=pk)






