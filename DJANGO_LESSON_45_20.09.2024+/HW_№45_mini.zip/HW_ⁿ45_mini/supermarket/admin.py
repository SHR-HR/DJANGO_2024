from django.contrib import admin
from django.utils.html import format_html
from django.shortcuts import redirect
from .models import SupermarketItem, EnhancedSupermarketItem

class EnhancedSupermarketItemInline(admin.TabularInline):
    model = EnhancedSupermarketItem
    extra = 1
    show_change_link = True

@admin.register(SupermarketItem)
class SupermarketItemAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'stock', 'price_controls', 'stock_controls', 'edit_link')
    list_editable = ('price',)
    search_fields = ('name', 'details')
    list_filter = ('price', 'stock')
    inlines = [EnhancedSupermarketItemInline]


    def price_controls(self, obj):
        return format_html(
            '<a class="button" href="{}">🔺</a> '
            '<a class="button" href="{}">🔻</a>',
            f'/admin/supermarket/supermarketitem/{obj.pk}/increase_price/',
            f'/admin/supermarket/supermarketitem/{obj.pk}/decrease_price/'
        )
    price_controls.short_description = 'Изменить цену'
    price_controls.allow_tags = True


    def stock_controls(self, obj):
        return format_html(
            '<a class="button" href="{}">⬆️</a> '
            '<a class="button" href="{}">⬇️</a>',
            f'/admin/supermarket/supermarketitem/{obj.pk}/increase_stock_unit/',
            f'/admin/supermarket/supermarketitem/{obj.pk}/decrease_stock_unit/'
        )
    stock_controls.short_description = 'Изменить количество на складе'
    stock_controls.allow_tags = True


    def edit_link(self, obj):
        return format_html(
            '<a class="button" href="{}">✏️</a>',
            f'/admin/supermarket/supermarketitem/{obj.pk}/change/'
        )
    edit_link.short_description = 'Редактировать'
    edit_link.allow_tags = True

    actions = ['increase_stock']


    def increase_stock(self, request, queryset):
        for item in queryset:
            item.stock += 10
            item.save()
        self.message_user(request, "Количество товаров увеличено на 10.")
    increase_stock.short_description = "Увеличить количество товара на складе на 10"


    def increase_price(self, request, obj_id):
        item = self.get_object(request, obj_id)
        if item:
            item.price += 10
            item.save()
        self.message_user(request, f"Цена товара '{item.name}' увеличена на 10.")
        return redirect(f'/admin/supermarket/supermarketitem/')

    def decrease_price(self, request, obj_id):
        item = self.get_object(request, obj_id)
        if item:
            item.price -= 10
            item.save()
        self.message_user(request, f"Цена товара '{item.name}' уменьшена на 10.")
        return redirect(f'/admin/supermarket/supermarketitem/')


    def increase_stock_unit(self, request, obj_id):
        item = self.get_object(request, obj_id)
        if item:
            item.stock += 1
            item.save()
        self.message_user(request, f"Количество товара '{item.name}' увеличено на 1.")
        return redirect(f'/admin/supermarket/supermarketitem/')

    def decrease_stock_unit(self, request, obj_id):
        item = self.get_object(request, obj_id)
        if item and item.stock > 0:
            item.stock -= 1
            item.save()
        self.message_user(request, f"Количество товара '{item.name}' уменьшено на 1.")
        return redirect(f'/admin/supermarket/supermarketitem/')


    def get_urls(self):
        from django.urls import path
        urls = super().get_urls()
        custom_urls = [
            path(
                '<int:obj_id>/increase_price/',
                self.admin_site.admin_view(self.increase_price),
                name='increase_price',
            ),
            path(
                '<int:obj_id>/decrease_price/',
                self.admin_site.admin_view(self.decrease_price),
                name='decrease_price',
            ),
            path(
                '<int:obj_id>/increase_stock_unit/',
                self.admin_site.admin_view(self.increase_stock_unit),
                name='increase_stock_unit',
            ),
            path(
                '<int:obj_id>/decrease_stock_unit/',
                self.admin_site.admin_view(self.decrease_stock_unit),
                name='decrease_stock_unit',
            ),
        ]
        return custom_urls + urls




