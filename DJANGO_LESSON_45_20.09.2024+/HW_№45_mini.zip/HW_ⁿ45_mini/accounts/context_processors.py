from django.contrib.auth.models import User, Group

def all_users_and_groups(request):
    users = User.objects.all()
    
    if request.user.is_authenticated:
        user_groups = request.user.groups.all()
    else:
        user_groups = None

    return {
        'all_users': users,
        'user_groups': user_groups
    }
