import os
from pathlib import Path

from django.contrib.messages import constants as messages

import sentry_sdk
from sentry_sdk.integrations.django import DjangoIntegration

# from decouple import config

BASE_DIR = Path(__file__).resolve().parent.parent



#  #  # # SECRET_KEY = 'django-insecure-k#+(cdr2df((#1)rce)f@s^cac6c4ekk6bu3nlf%au3&0)3z@9'
SECRET_KEY = os.getenv('DJANGO_SECRET_KEY', 'ваш-бэкап-ключ-на-локальной-среде')



DEBUG = True
# DEBUG = False
#  #  # # DEBUG = os.getenv('DJANGO_DEBUG', 'False') == 'True'
if not DEBUG:
    STATIC_ROOT = os.path.join(BASE_DIR, 'static')




#  #  # # ALLOWED_HOSTS = []
#  #  # # ALLOWED_HOSTS = ['mywebsite.com', 'www.mywebsite.com']
ALLOWED_HOSTS = ['localhost', '127.0.0.1', 'mywebsite.com']
# ALLOWED_HOSTS = ['127.0.0.1', 'localhost']



INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'myproject',
    'amenities',
    'rooms',
    'supermarket',
    'markupfield',
    'precise_bbcode',
    'django_cleanup.apps.CleanupConfig',
    'easy_thumbnails',
    'validation',
    'rest_framework',
    'accounts',
    'django.contrib.sites',
    'allauth',
    'allauth.account',
    'allauth.socialaccount',
    'allauth.socialaccount.providers.google',
    'django_extensions',
    'boss',
    'custom_email_send',
    'custom_low_level_email',
    'todo_list',
    'client_cache',
]



MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'allauth.account.middleware.AccountMiddleware',
]

#  #  # # MIDDLEWARE.append('django.middleware.csrf.CsrfViewMiddleware')

#  #  # # MIDDLEWARE.remove('django.middleware.csrf.CsrfViewMiddleware')



ROOT_URLCONF = 'myproject.urls'



TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'accounts.context_processors.all_users_and_groups',
            ],
        },
    },
]



WSGI_APPLICATION = 'myproject.wsgi.application'



DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': 'myproject',
        'USER': 'postgres',
        'PASSWORD': 'sql12345',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}



AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
    {
        'NAME': 'validation.validators.CustomPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
        'OPTIONS': {
            'min_length': 8,
        }
    },
]



LANGUAGE_CODE = 'ru-ru'


TIME_ZONE = 'Asia/Almaty'


USE_I18N = True


USE_L10N = True


USE_TZ = True



STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')
STATICFILES_DIRS = [
    os.path.join(BASE_DIR, 'static'),
]



MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')


DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'


THUMBNAIL_ALIASES = {
    '': {
        'small': {'size': (900, 900), 'crop': True},
        'medium': {'size': (1200, 1200), 'crop': True},
    },
}


THUMBNAIL_BASEDIR = 'thumbnails'


EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True


EMAIL_HOST_USER = 'paitondjangovich0709101@gmail.com'
# EMAIL_HOST_USER = os.getenv('EMAIL_HOST_USER')

EMAIL_HOST_PASSWORD = 'noin oiqx uwqp yvmn'
# EMAIL_HOST_PASSWORD = os.getenv('EMAIL_HOST_PASSWORD')


# EMAIL_HOST_USER = config('EMAIL_HOST_USER')
# EMAIL_HOST_PASSWORD = config('EMAIL_HOST_PASSWORD')

DEFAULT_FROM_EMAIL = 'paitondjangovich0709101@gmail.com'


SITE_ID = 1


AUTHENTICATION_BACKENDS = (
    'django.contrib.auth.backends.ModelBackend',
    'allauth.account.auth_backends.AuthenticationBackend',
)



LOGIN_REDIRECT_URL = '/'
ACCOUNT_LOGOUT_REDIRECT_URL = '/'
ACCOUNT_EMAIL_VERIFICATION = 'none'
ACCOUNT_AUTHENTICATION_METHOD = 'email'
ACCOUNT_EMAIL_REQUIRED = True



SOCIALACCOUNT_PROVIDERS = {
    'google': {
        'SCOPE': ['email', 'profile'],
        'AUTH_PARAMS': {'access_type': 'online'},
        'OAUTH_CLIENT_ID': '442529875524-21toe8kg0hkv5b1do1v494gd4gnqr0f6.apps.googleusercontent.com',
        'OAUTH_CLIENT_SECRET': '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',
        'APP': {
            'client_id': '442529875524-21toe8kg0hkv5b1do1v494gd4gnqr0f6.apps.googleusercontent.com',
            'secret': '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',
            'key': ''
        }
    }
}



MESSAGE_TAGS = {
    messages.DEBUG: 'debug',
    messages.INFO: 'info',
    messages.SUCCESS: 'success',
    messages.WARNING: 'warning',
    messages.ERROR: 'error',
    50: 'important'
}



# Добавл настройки для Redis
CACHES = {
    'default': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': 'redis://127.0.0.1:6379/1',
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient',
        }
    },
    'session_storage': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': 'redis://127.0.0.1:6379/2',
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient',
        }
    }
}



# Настройка использования Redis для хранения сессий
SESSION_ENGINE = 'django.contrib.sessions.backends.cache'
#  #  # SESSION_CACHE_ALIAS = 'session_storage'
SESSION_CACHE_ALIAS = 'default'
SESSION_COOKIE_SECURE = True



# LOGGING = {
#     'version': 1,
#     'disable_existing_loggers': False,
#     'handlers': {
#         'file': {
#             'level': 'ERROR',
#             'class': 'logging.FileHandler',
#             'filename': os.path.join(BASE_DIR, 'django_errors.log'),
#         },
#     },
#     'loggers': {
#         'django': {
#             'handlers': ['file'],
#             'level': 'ERROR',
#             'propagate': True,
#         },
#     },
# }



LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'file': {
            'level': 'ERROR',
            'class': 'logging.FileHandler',
            'filename': os.path.join(BASE_DIR, 'django_errors.log'),
        },
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'loggers': {
        'django': {
            'handlers': ['file', 'console'],
            'level': 'ERROR',
            'propagate': True,
        },
    },
}



SECURE_SSL_REDIRECT = False
# SECURE_SSL_REDIRECT = True

SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True


# Для сжатия и минимизации статических файлов
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'



X_FRAME_OPTIONS = 'DENY'

CSRF_COOKIE_SECURE = True



sentry_sdk.init(
    dsn="https://596c093d9f35d1a50df8a5d6fe9f2ff5@o4507992982028288.ingest.de.sentry.io/4507992997822544",
    integrations=[DjangoIntegration()],
    traces_sample_rate=1.0,
    send_default_pii=True
)




