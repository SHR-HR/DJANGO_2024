from django.shortcuts import render, redirect
from amenities.models import Amenity
from rooms.models import Room
from supermarket.models import SupermarketItem

from django.contrib import messages
from django.core import signing
from django.contrib.auth.models import User

# Функция для отображения главной страницы с данными из моделей
def home(request):
    amenities = Amenity.objects.all()
    rooms = Room.objects.all()
    supermarket_items = SupermarketItem.objects.all()
    
    return render(request, 'main.html', {
        'amenities': amenities,
        'rooms': rooms,
        'supermarket_items': supermarket_items,
    })

# Функция для отображения успешного сообщения
def my_view(request):
    try:
        user = User.objects.get(username='testuser0')
    except User.DoesNotExist:
        user = None

    if user:
        data = {
            'username': user.username,
            'email': user.email
        }
        signed_data = signing.dumps(data)
        try:
            original_data = signing.loads(signed_data)
        except signing.BadSignature:
            original_data = None
    else:
        signed_data = None
        original_data = None

    messages.success(request, 'Ваше сообщение успешно отправлено!')

    return render(request, 'main.html', {
        'signed_data': signed_data,
        'original_data': original_data,
        'amenities': Amenity.objects.all(),
        'rooms': Room.objects.all(),
        'supermarket_items': SupermarketItem.objects.all(),
    })

# Функция для отображения важного сообщения
def important_message_view(request):
    try:
        user = User.objects.get(username='testuser0')
    except User.DoesNotExist:
        user = None

    if user:
        data = {
            'username': user.username,
            'email': user.email
        }
        signed_data = signing.dumps(data)
        try:
            original_data = signing.loads(signed_data)
        except signing.BadSignature:
            original_data = None
    else:
        signed_data = None
        original_data = None

    messages.add_message(request, 50, 'Это важное сообщение об выполнении Домашнего Задания №41!')

    return render(request, 'main.html', {
        'signed_data': signed_data,
        'original_data': original_data,
        'amenities': Amenity.objects.all(),
        'rooms': Room.objects.all(),
        'supermarket_items': SupermarketItem.objects.all(),
    })

# Функция для тестирования ошибок Sentry
def trigger_error(request):
    division_by_zero = 1 / 0

# Функция для отображения подписанных данных
def sign_data_view(request):
    try:
        user = User.objects.get(username='testuser0')
    except User.DoesNotExist:
        user = None

    if user:
        data = {
            'username': user.username,
            'email': user.email
        }
        signed_data = signing.dumps(data)
        try:
            original_data = signing.loads(signed_data)
        except signing.BadSignature:
            original_data = None
    else:
        signed_data = None
        original_data = None

    return render(request, 'main.html', {
        'signed_data': signed_data,
        'original_data': original_data,
        'amenities': Amenity.objects.all(),
        'rooms': Room.objects.all(),
        'supermarket_items': SupermarketItem.objects.all()
    })

# Пользовательские страницы ошибок
def page_not_found(request, exception):
    return render(request, '404.html', status=404)

def server_error(request):
    return render(request, '500.html', status=500)


