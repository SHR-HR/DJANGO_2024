from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from .views import home
from allauth.socialaccount.views import ConnectionsView

from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('allauth.urls')),
    path('', home, name='home'),
    path('amenities/', include('amenities.urls')),
    path('cards/', include('amenities.urls_cards')),
    path('ul-list/', include('amenities.urls_ul_list')),
    path('json/', include('amenities.urls_json')),
    path('rooms/', include('rooms.urls')),
    path('supermarket/', include('supermarket.urls')),
    path('validation/', include('validation.urls')),
    path('accounts/', include('accounts.urls')),
    path('accounts/social/connections/', ConnectionsView.as_view(), name='socialaccount_connections'),
    path('my-view/', views.my_view, name='my_view'),
    path('sign-data/', views.sign_data_view, name='sign_data'),
    path('important-message/', views.important_message_view, name='important_message'),
    path('boss/', include('boss.urls')),
    path('custom_email/', include('custom_email_send.urls')),
    path('low_level_email/', include('custom_low_level_email.urls')),
    path('tasks/', include('todo_list.urls')),
    path('client-cache/', include('client_cache.urls')),
]

# Если в режиме отладки, добавляем статические маршруты
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# Обработчики ошибок
handler404 = 'myproject.views.page_not_found'
handler500 = 'myproject.views.server_error'

# Добавляем маршрут для тестирования Sentry
urlpatterns += [
    path('sentry-debug/', views.trigger_error),
]
