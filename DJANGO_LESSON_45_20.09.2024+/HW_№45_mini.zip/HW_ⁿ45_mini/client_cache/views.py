from django.shortcuts import render
from django.views.decorators.cache import cache_control
import logging
from django.core.cache import cache
import json

# Кэширование страницы на сервере (Redis)
@cache_control(max_age=120)  #2 минуты
def index(request):
    return render(request, 'index.html')


# Настраиваем логирование
logger = logging.getLogger(__name__)

def my_view(request):
    # Попытка получить объект из кэша
    cached_data = cache.get('SasaiKUDASAI')  
    if cached_data is None:
        logger.info('Cache miss for key: SasaiKUDASAI')
        # Если данных в кэше нет, получаем их из базы и кэшируем
        cached_data = 'Данные для кэширования'
        cache.set('SasaiKUDASAI', cached_data, timeout=60)
    else:
        logger.info('Cache hit for key: SasaiKUDASAI')

    return render(request, 'my_template.html', {'data': cached_data})


def all_data_view(request):
    # Загрузим все данные из сериализованных файлов
    models_data = {}
    
    # Пример, как загрузить несколько JSON файлов (добавьте свои модели)
    model_files = ['user.json', 'task.json', 'supermarketitem.json']
    
    for model_file in model_files:
        with open(f'path_to_json/{model_file}', 'r', encoding='utf-8') as file:
            models_data[model_file.split('.')[0]] = json.load(file)
    
    return render(request, 'all_data_template.html', {'models_data': models_data})



