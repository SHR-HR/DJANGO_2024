from django.contrib import admin
from .models import Profile

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'bio', 'location', 'birth_date')
    search_fields = ('user__username', 'bio', 'location')
    list_filter = ('location', 'birth_date')
    readonly_fields = ('user', 'birth_date')


    def get_list_display(self, request):
        return ('user', 'location', 'birth_date')


    date_hierarchy = 'birth_date'



