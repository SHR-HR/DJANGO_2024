from django.core.mail import send_mail, EmailMessage, EmailMultiAlternatives
from django.conf import settings
from django.shortcuts import render
from django.urls import reverse
from django.utils.http import urlsafe_base64_encode
from django.utils.encoding import force_bytes
from django.contrib.auth.tokens import default_token_generator
from django.contrib.auth.models import User

def send_custom_email(request):
    if request.method == "POST":
        email = request.POST.get('email')
        subject = request.POST.get('subject', 'Без темы')
        message = request.POST.get('message', 'Без сообщения')
        password_reset = request.POST.get('password_reset', None)
        send_html = request.POST.get('send_html', None)
        send_attachment = request.FILES.get('attachment', None)
        mass_send = request.POST.get('mass_send', None)
        
        recipient_list = []
        if mass_send == 'on':
            emails = request.POST.get('mass_emails').split(',')
            recipient_list = [email.strip() for email in emails]
        else:
            recipient_list = [email]

        # Если флажок "Восстановить пароль" выбран, проверяем email
        if password_reset == 'on':
            invalid_emails = []
            valid_emails = []
            for recipient in recipient_list:
                try:
                    User.objects.get(email=recipient)
                    valid_emails.append(recipient)
                except User.DoesNotExist:
                    invalid_emails.append(recipient)

            if invalid_emails:
                return render(request, 'custom_email_send/send_email_form.html', {
                    'error': f'Эти email адреса не зарегистрированы: {", ".join(invalid_emails)}. Пожалуйста, зарегистрируйтесь!'
                })

            if len(valid_emails) == 1:
                user = User.objects.get(email=valid_emails[0])
                uid = urlsafe_base64_encode(force_bytes(user.pk))
                token = default_token_generator.make_token(user)
                reset_url = request.build_absolute_uri(reverse('password_reset_confirm', kwargs={
                    'uidb64': uid,
                    'token': token,
                }))
                subject = 'Восстановление пароля'
                message = f'Пожалуйста, перейдите по ссылке для восстановления пароля: {reset_url}'
                recipient_list = [valid_emails[0]]

        # Если выбран флажок "Отправить HTML письмо"
        if send_html == 'on':
            email_message = EmailMultiAlternatives(subject, message, settings.DEFAULT_FROM_EMAIL, recipient_list)
            html_content = f'<h1>{message}</h1><p>Это HTML-версия вашего письма.</p>'
            email_message.attach_alternative(html_content, "text/html")

            # Если есть вложение, добавляем его
            if send_attachment:
                email_message.attach(send_attachment.name, send_attachment.read(), send_attachment.content_type)

            email_message.send()
            print("HTML письмо отправлено с вложением")
        elif send_attachment:
            # Если только вложение
            email_message = EmailMessage(subject, message, settings.DEFAULT_FROM_EMAIL, recipient_list)
            email_message.attach(send_attachment.name, send_attachment.read(), send_attachment.content_type)
            email_message.send()
            print("Письмо с вложением отправлено")
        else:
            # Обычное письмо
            send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, recipient_list, fail_silently=False)
            print("Обычное письмо отправлено")

        return render(request, 'custom_email_send/email_sent.html', {'email': ', '.join(recipient_list)})

    return render(request, 'custom_email_send/send_email_form.html')




