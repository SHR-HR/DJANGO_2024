from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('send_email/', views.send_custom_email, name='send_custom_email'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
]

