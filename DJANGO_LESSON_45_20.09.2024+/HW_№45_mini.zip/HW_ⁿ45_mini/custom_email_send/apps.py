from django.apps import AppConfig


class CustomEmailSendConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'custom_email_send'



