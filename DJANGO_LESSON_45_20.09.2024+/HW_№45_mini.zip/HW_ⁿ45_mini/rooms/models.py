from django.db import models
from django.contrib.postgres.fields import DateRangeField
from django.contrib.postgres.indexes import GistIndex
from django.contrib.postgres.constraints import ExclusionConstraint
from django.contrib.postgres.validators import RangeMinValueValidator, RangeMaxValueValidator
from datetime import date
from amenities.models import Amenity

class Room(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название комнаты")
    beds = models.IntegerField(verbose_name="Количество кроватей", default=1)
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Цена", default=0.00)
    available_dates = DateRangeField(
        verbose_name="Доступные даты",
        validators=[
            RangeMinValueValidator(date(2022, 1, 1)),
            RangeMaxValueValidator(date(2030, 12, 31))
        ],
        # Изменяем значение по умолчанию на None и разрешаем null
        default=None,  # Устанавливаем значение по умолчанию как None
        null=True,
        blank=True,
    )
    image = models.ImageField(upload_to='rooms/', null=True, blank=True, verbose_name="Изображение")
    file = models.FileField(upload_to='rooms/files/', blank=True, null=True, verbose_name="Документ (xlsx/pdf)")

    class Meta:
        verbose_name = "Комната"
        verbose_name_plural = "Комнаты"
        indexes = [
            GistIndex(fields=['available_dates']),
        ]
        constraints = [
            ExclusionConstraint(
                name='exclude_overlapping_dates',
                expressions=[
                    ('available_dates', '&&'),
                ],
            ),
        ]

    def __str__(self):
        return self.name


class EnhancedRoom(models.Model):
    room = models.ForeignKey(Room, on_delete=models.CASCADE, verbose_name="Тип комнаты")
    room_number = models.CharField(max_length=10, verbose_name="Номер комнаты", unique=True)
    floor = models.IntegerField(verbose_name="Этаж")
    room_type = models.CharField(max_length=50, verbose_name="Тип комнаты")
    amenities = models.ManyToManyField(Amenity, verbose_name="Удобства", blank=True)

    class Meta:
        verbose_name = "Расширенная Комната"
        verbose_name_plural = "Расширенные Комнаты"

    def __str__(self):
        return f"{self.room.name} - {self.room_number} (Этаж: {self.floor})"






