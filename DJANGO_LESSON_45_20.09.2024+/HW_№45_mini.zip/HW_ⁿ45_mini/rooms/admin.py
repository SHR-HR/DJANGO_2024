from django.contrib import admin
from django.utils.html import format_html
from django.shortcuts import redirect
from .models import Room, EnhancedRoom

class EnhancedRoomInline(admin.TabularInline):
    model = EnhancedRoom
    extra = 1
    show_change_link = True

@admin.register(Room)
class RoomAdmin(admin.ModelAdmin):
    list_display = ('name', 'beds', 'available_dates', 'price', 'price_controls', 'edit_link')
    list_editable = ('price',)
    search_fields = ('name',)
    list_filter = ('beds',)
    inlines = [EnhancedRoomInline]

    def price_controls(self, obj):
        return format_html(
            '<a class="button" href="{}">🔺</a> '
            '<a class="button" href="{}">🔻</a>',
            f'/admin/rooms/room/{obj.pk}/increase_price/',
            f'/admin/rooms/room/{obj.pk}/decrease_price/'
        )
    price_controls.short_description = 'Изменить цену'
    price_controls.allow_tags = True

    def edit_link(self, obj):
        return format_html(
            '<a class="button" href="{}">✏️</a>',
            f'/admin/rooms/room/{obj.pk}/change/'
        )
    edit_link.short_description = 'Редактировать'
    edit_link.allow_tags = True

    actions = ['increase_price', 'decrease_price']

    def increase_price(self, request, queryset):
        for room in queryset:
            room.price += 10
            room.save()
        self.message_user(request, "Цена была увеличена на 10.")
    increase_price.short_description = "Увеличить цену на 10"

    def decrease_price(self, request, queryset):
        for room in queryset:
            room.price -= 10
            room.save()
        self.message_user(request, "Цена была уменьшена на 10.")
    decrease_price.short_description = "Уменьшить цену на 10"

    def get_urls(self):
        from django.urls import path
        urls = super().get_urls()
        custom_urls = [
            path(
                '<int:obj_id>/increase_price/',
                self.admin_site.admin_view(self.increase_price_single),
                name='increase_price',
            ),
            path(
                '<int:obj_id>/decrease_price/',
                self.admin_site.admin_view(self.decrease_price_single),
                name='decrease_price',
            ),
        ]
        return custom_urls + urls

    def increase_price_single(self, request, obj_id):
        room = self.get_object(request, obj_id)
        if room:
            room.price += 10
            room.save()
        self.message_user(request, f"Цена комнаты '{room.name}' увеличена на 10.")
        return redirect(f'/admin/rooms/room/')

    def decrease_price_single(self, request, obj_id):
        room = self.get_object(request, obj_id)
        if room:
            room.price -= 10
            room.save()
        self.message_user(request, f"Цена комнаты '{room.name}' уменьшена на 10.")
        return redirect(f'/admin/rooms/room/')





