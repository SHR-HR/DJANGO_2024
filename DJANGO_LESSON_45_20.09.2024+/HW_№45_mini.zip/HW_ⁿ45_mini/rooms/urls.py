from django.urls import path
from . import views

urlpatterns = [
    path('list/', views.rooms_list, name='rooms_list'),
    path('<int:pk>/', views.room_detail, name='room_detail'),
    path('<int:pk>/upload_image/', views.upload_room_image, name='upload_room_image'),
    path('<int:pk>/delete_image/', views.delete_room_image, name='delete_room_image'),
    path('<int:pk>/upload_file/', views.room_detail, name='upload_room_file'),
    path('<int:pk>/delete_file/', views.room_detail, name='delete_room_file'),
    path('<int:pk>/cleanup_test/', views.cleanup_test, name='cleanup_test'),
]


