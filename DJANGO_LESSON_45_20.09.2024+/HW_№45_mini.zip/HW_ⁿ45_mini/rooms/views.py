from django.shortcuts import render, redirect, get_object_or_404
from .models import Room

def rooms_list(request):
    rooms = Room.objects.all()
    return render(request, 'rooms_list.html', {'rooms': rooms})

def room_detail(request, pk):
    room = get_object_or_404(Room, pk=pk)
    
    if request.method == "POST":
        if 'image' in request.FILES:
            room.image = request.FILES.get('image')
            room.save()
        elif 'delete_image' in request.POST:
            room.image.delete()
            room.image = None
            room.save()
        elif 'file' in request.FILES:
            room.file = request.FILES.get('file')
            room.save()
        elif 'delete_file' in request.POST:
            room.file.delete()
            room.file = None
            room.save()
        return redirect('room_detail', pk=pk)

    return render(request, 'room_detail.html', {'room': room})

def upload_room_image(request, pk):
    room = get_object_or_404(Room, pk=pk)
    if request.method == "POST":
        room.image = request.FILES.get('image')
        room.save()
    return redirect('room_detail', pk=pk)

def delete_room_image(request, pk):
    room = get_object_or_404(Room, pk=pk)
    if room.image:
        room.image.delete()
        room.image = None
        room.save()
    return redirect('room_detail', pk=pk)


def cleanup_test(request, pk):
    room = get_object_or_404(Room, pk=pk)

    if request.method == "POST":
        if 'delete_image' in request.POST:
            room.image.delete()
            room.image = None
            room.save()
        elif 'delete_file' in request.POST:
            room.file.delete()
            room.file = None
            room.save()

        return redirect('room_detail', pk=pk)

    return render(request, 'cleanup_test.html', {'room': room})



