from django.core.mail import EmailMessage, EmailMultiAlternatives
from django.conf import settings
from django.shortcuts import render
from django.urls import reverse
from django.utils.http import urlsafe_base64_encode
from django.utils.encoding import force_bytes
from django.contrib.auth.tokens import default_token_generator
from django.contrib.auth.models import User

# Отправка письма с использованием низкоуровневого метода EmailMessage
def send_low_level_email(request):
    error = None
    if request.method == "POST":
        email = request.POST.get('email')
        subject = request.POST.get('subject', 'Без темы')
        message = request.POST.get('message', 'Без сообщения')
        password_reset = request.POST.get('password_reset', None)
        send_html = request.POST.get('send_html', None)
        send_attachment = request.FILES.get('attachment', None)

        # Если выбран флажок восстановления пароля
        if password_reset == 'on':
            try:
                user = User.objects.get(email=email)
                uid = urlsafe_base64_encode(force_bytes(user.pk))
                token = default_token_generator.make_token(user)
                reset_url = request.build_absolute_uri(reverse('password_reset_confirm', kwargs={
                    'uidb64': uid,
                    'token': token,
                }))
                subject = 'Восстановление пароля'
                message = f'Пожалуйста, перейдите по ссылке для восстановления пароля: {reset_url}'
            except User.DoesNotExist:
                error = f"Пользователь с таким email не найден: {email}."
                return render(request, 'custom_low_level_email/send_email_form.html', {'error': error, 'is_mass_email': False})

        # Отправляем письмо с HTML, если выбран флажок HTML
        if send_html == 'on':
            email_message = EmailMultiAlternatives(subject, message, settings.DEFAULT_FROM_EMAIL, [email])
            html_content = f'<h1>{message}</h1><p>Это HTML-версия письма.</p>'
            email_message.attach_alternative(html_content, "text/html")
            if send_attachment:
                email_message.attach(send_attachment.name, send_attachment.read(), send_attachment.content_type)
            email_message.send()
        elif send_attachment:
            # Если выбрано только вложение
            email_message = EmailMessage(subject, message, settings.DEFAULT_FROM_EMAIL, [email])
            email_message.attach(send_attachment.name, send_attachment.read(), send_attachment.content_type)
            email_message.send()
        else:
            # Обычное письмо
            email_message = EmailMessage(subject, message, settings.DEFAULT_FROM_EMAIL, [email])
            email_message.send()

        return render(request, 'custom_low_level_email/email_sent.html', {'email': email})

    return render(request, 'custom_low_level_email/send_email_form.html', {'is_mass_email': False})


# Отправка массива писем с восстановлением пароля и поддержкой HTML
def send_mass_low_level_emails(request):
    error = None
    if request.method == "POST":
        emails = request.POST.get('emails').split(',')
        subject = request.POST.get('subject', 'Без темы')
        send_html_mass = request.POST.get('send_html_mass', None)

        valid_emails = []
        for email in emails:
            email = email.strip()
            try:
                user = User.objects.get(email=email)
                uid = urlsafe_base64_encode(force_bytes(user.pk))
                token = default_token_generator.make_token(user)
                reset_url = request.build_absolute_uri(reverse('password_reset_confirm', kwargs={
                    'uidb64': uid,
                    'token': token,
                }))
                valid_emails.append({
                    'email': email,
                    'subject': subject,
                    'message': f'Пожалуйста, перейдите по ссылке для восстановления пароля: {reset_url}'
                })
            except User.DoesNotExist:
                error = f"Пользователь с таким email не найден: {email}."
                return render(request, 'custom_low_level_email/send_email_form.html', {'error': error, 'is_mass_email': True})

        for email_info in valid_emails:
            # Отправляем письмо с HTML, если выбран флажок
            if send_html_mass == 'on':
                email_message = EmailMultiAlternatives(email_info['subject'], email_info['message'], settings.DEFAULT_FROM_EMAIL, [email_info['email']])
                html_content = f'<h1>{email_info["message"]}</h1><p>Это HTML-версия письма.</p>'
                email_message.attach_alternative(html_content, "text/html")
                email_message.send()
            else:
                email_message = EmailMessage(email_info['subject'], email_info['message'], settings.DEFAULT_FROM_EMAIL, [email_info['email']])
                email_message.send()

        return render(request, 'custom_low_level_email/email_sent.html', {'email': ', '.join([email_info['email'] for email_info in valid_emails])})

    return render(request, 'custom_low_level_email/send_email_form.html', {'is_mass_email': True})



