from django.urls import path
from . import views

urlpatterns = [
    path('send_low_level_email/', views.send_low_level_email, name='send_low_level_email'),
    path('send_mass_emails/', views.send_mass_low_level_emails, name='send_mass_low_level_emails'),
]


