from django.http import JsonResponse
from django.contrib.auth.models import User


def get_active_users(request):
    active_users = User.objects.filter(is_active=True)
    users_data = [{'id': user.id, 'username': user.username} for user in active_users]
    return JsonResponse(users_data, safe=False)


def create_user(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        if username and password:
            User.objects.create_user(username=username, password=password)
            return JsonResponse({'status': 'Пользователь создан успешно'})
        return JsonResponse({'error': 'Не указаны имя пользователя или пароль'}, status=400)
    return JsonResponse({'error': 'Требуется POST-запрос'}, status=400)
