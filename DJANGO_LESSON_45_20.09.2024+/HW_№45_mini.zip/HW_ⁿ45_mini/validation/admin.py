from django.contrib import admin
from .models import ValidationModel

@admin.register(ValidationModel)
class ValidationModelAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')
    search_fields = ('name', 'description')
    list_filter = ('name',)

    ordering = ('name',)




