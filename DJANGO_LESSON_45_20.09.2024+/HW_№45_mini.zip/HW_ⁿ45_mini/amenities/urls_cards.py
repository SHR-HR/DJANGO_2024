from django.urls import path
from . import views

urlpatterns = [
    path('', views.amenity_cards, name='amenity_cards'),
]



