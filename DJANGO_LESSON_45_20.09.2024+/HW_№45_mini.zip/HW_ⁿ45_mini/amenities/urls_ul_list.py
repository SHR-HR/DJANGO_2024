from django.urls import path
from . import views

urlpatterns = [
    path('', views.amenity_ul_list, name='amenity_ul_list'),
]



