from django.contrib import admin
from django.utils.html import format_html
from django.shortcuts import redirect
from .models import Amenity

@admin.register(Amenity)
class AmenityAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'available_times', 'price_controls', 'edit_link')
    list_display_links = ('name',)
    search_fields = ('name', 'description', 'tags')
    list_filter = ('price', 'tags')
    ordering = ('-price',)
    sortable_by = ('price', 'available_times')

    actions = ['mark_as_vip']


    def price_controls(self, obj):
        return format_html(
            '<a class="button" href="{}">🔺</a> '
            '<a class="button" href="{}">🔻</a>',
            f'/admin/amenities/amenity/{obj.pk}/increase_price/',
            f'/admin/amenities/amenity/{obj.pk}/decrease_price/'
        )
    price_controls.short_description = 'Изменить цену'
    price_controls.allow_tags = True


    def edit_link(self, obj):
        return format_html(
            '<a class="button" href="{}">✏️</a>',
            f'/admin/amenities/amenity/{obj.pk}/change/'
        )
    edit_link.short_description = 'Редактировать'
    edit_link.allow_tags = True

    def mark_as_vip(self, request, queryset):
        queryset.update(vip_service=True)
        self.message_user(request, "Выбранные удобства были отмечены как VIP.")
    mark_as_vip.short_description = "Отметить как VIP"


    def increase_price(self, request, obj_id):
        amenity = self.get_object(request, obj_id)
        if amenity:
            amenity.price += 10
            amenity.save()
        self.message_user(request, f"Цена удобства '{amenity.name}' увеличена на 10.")
        return redirect(f'/admin/amenities/amenity/')

    def decrease_price(self, request, obj_id):
        amenity = self.get_object(request, obj_id)
        if amenity:
            amenity.price -= 10
            amenity.save()
        self.message_user(request, f"Цена удобства '{amenity.name}' уменьшена на 10.")
        return redirect(f'/admin/amenities/amenity/')


    def get_urls(self):
        from django.urls import path
        urls = super().get_urls()
        custom_urls = [
            path(
                '<int:obj_id>/increase_price/',
                self.admin_site.admin_view(self.increase_price),
                name='increase_price',
            ),
            path(
                '<int:obj_id>/decrease_price/',
                self.admin_site.admin_view(self.decrease_price),
                name='decrease_price',
            ),
        ]
        return custom_urls + urls




