from django.urls import path
from . import views

urlpatterns = [
    path('<int:pk>/', views.amenity_detail, name='amenity_detail'),
    path('add_amenity/', views.add_amenity, name='add_amenity'),
    path('list/', views.amenity_list, name='amenity_list'),
    path('<int:pk>/upload_image/', views.upload_image, name='upload_image'),
    path('<int:pk>/delete_image/', views.delete_image, name='delete_image'),
    path('<int:pk>/upload_file/', views.amenity_detail, name='upload_file'),
    path('<int:pk>/delete_file/', views.amenity_detail, name='delete_file'),
]


