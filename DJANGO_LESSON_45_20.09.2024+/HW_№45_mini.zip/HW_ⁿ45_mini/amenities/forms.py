from django import forms
from .models import Amenity

class AmenityForm(forms.ModelForm):
    class Meta:
        model = Amenity
        fields = ['name', 'description_bbcode', 'price', 'image', 'file']
        widgets = {
            'description_bbcode': forms.Textarea(attrs={'rows': 4, 'cols': 40}),
        }

class AmenityImageForm(forms.ModelForm):
    class Meta:
        model = Amenity
        fields = ['image']




