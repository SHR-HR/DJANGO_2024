from django import template

register = template.Library()

@register.filter(name='cut_half')
def cut_half(value):
    half_index = len(value) // 2
    return value[:half_index]

@register.filter(name='to_uppercase')
def to_uppercase(value):

    return value.upper()

@register.filter(name='reverse_string')
def reverse_string(value):

    return value[::-1]

