from django import template
import math

register = template.Library()

@register.simple_tag
def split_string(value, separator=','):
    return value.split(separator)

@register.simple_tag
def factorial(value):

    try:
        num = int(value)
        return math.factorial(num)
    except (ValueError, TypeError):
        return 'Ошибка: введите целое число'

@register.simple_tag
def make_list(value):

    items = value.split()
    html_list = '<ul>'
    for item in items:
        html_list += f'<li>{item}</li>'
    html_list += '</ul>'
    return html_list


