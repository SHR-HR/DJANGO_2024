from django.shortcuts import render, redirect, get_object_or_404
from .models import Task
from .forms import TaskForm
from django.views.decorators.cache import cache_page
from django.contrib.auth.decorators import login_required
from django.db.models.signals import post_save, post_delete
from django.core.cache import cache
from django.dispatch import receiver
import logging
from django.core.cache import cache



@cache_page(60 * 2)
@login_required
def task_list(request):
    tasks = Task.objects.filter(user=request.user)
    return render(request, 'todo_list/task_list.html', {'tasks': tasks})



@cache_page(60 * 2)
@login_required
def task_create(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.user = request.user
            task.save()
            return redirect('task_list')
    else:
        form = TaskForm()
    return render(request, 'todo_list/task_form.html', {'form': form})



@login_required
def task_edit(request, pk):
    task = get_object_or_404(Task, pk=pk, user=request.user)
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect('task_list')
    else:
        form = TaskForm(instance=task)
    return render(request, 'todo_list/task_form.html', {'form': form})



@cache_page(60 * 2)
@login_required
def task_delete(request, pk):
    task = Task.objects.get(pk=pk)
    if request.method == 'POST':
        task.delete()
        return redirect('task_list')
    return render(request, 'todo_list/task_confirm_delete.html', {'task': task})



@receiver(post_save, sender=Task)
def clear_task_cache_on_save(sender, instance, **kwargs):
    cache.delete('task_list_cache_key')



@receiver(post_delete, sender=Task)
def clear_task_cache_on_delete(sender, instance, **kwargs):
    cache.delete('task_list_cache_key')



# Настраиваем логирование
logger = logging.getLogger(__name__)

def my_view(request):
    # Попытка получить объект из кэша
    cached_data = cache.get('my_key')  # Заменить 'my_key' на нужный ключ
    if cached_data is None:
        logger.info('Cache miss for key: my_key')
        # Если данных в кэше нет, получаем их из базы и кэшируем
        cached_data = 'Данные для кэширования'
        cache.set('my_key', cached_data, timeout=60)  # Кэшируем данные на 60 секунд
    else:
        logger.info('Cache hit for key: my_key')

    return render(request, 'my_template.html', {'data': cached_data})





