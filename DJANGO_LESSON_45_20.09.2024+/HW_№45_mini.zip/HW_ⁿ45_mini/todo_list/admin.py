from django.contrib import admin
from .models import Task

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ('title', 'description', 'completed', 'created_at', 'user')
    search_fields = ('title', 'description')
    list_filter = ('completed', 'user')
    readonly_fields = ('created_at',)


    actions = ['mark_as_completed']

    def mark_as_completed(self, request, queryset):
        queryset.update(completed=True)
        self.message_user(request, "Выбранные задачи отмечены как завершенные.")
    mark_as_completed.short_description = "Отметить задачи как завершенные"


